module.exports = {
  HOST: "localhost",
  USER: "sa", 
  PASSWORD: "tiger",
  DB: "multiple_forms"
};

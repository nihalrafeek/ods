// const BusinessLine = require("../models/suppliers.model");

var sql = require("mssql");
var dbConfig = require("../config/db.config");

var config = {
    user: dbConfig.USER,
    password: dbConfig.PASSWORD,
    server: dbConfig.HOST,
    database: dbConfig.DB
};


// Create and Save a new Customer
exports.create = (req, res) => {
    // Validate request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    sql.connect(config, function (err) {

        if (err) console.log(err);

        var request = new sql.Request();
        let queryString = `INSERT INTO suppliers VALUES ('${req.body.code}', '${req.body.status}', '${req.body.name}', '${req.body.arabic_name}', '${req.body.address}', '${req.body.phone}', '${req.body.country_id}', '${req.body.state_id}', '${req.body.city_id}', '${req.body.currency_id}', '${req.body.sales_rep_id}', '${req.body.related_party}', '${req.body.credit_limit}', '${req.body.vat_number}')`;
        console.log(queryString);

        request.query(queryString, function (err, recordset) {

            if (err) console.log(err)

            res.json(recordset);

        });
    });

};

// Retrieve all suppliers from the database.
exports.findAll = (req, res) => {
    sql.connect(config, function (err) {

        if (err) console.log(err);

        var request = new sql.Request();

        request.query('select * from suppliers order by id desc', function (err, recordset) {

            if (err) console.log(err)

            res.json(recordset);

        });
    });

};

// Find a single Customer with a customerId
exports.findOne = (req, res) => {

    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    sql.connect(config, function (err) {

        if (err) console.log(err);

        var request = new sql.Request();
        var query = `SELECT * FROM suppliers WHERE id = ${req.body.id}`;

        console.log(query);

        request.query(query, function (err, recordset) {

            if (err) console.log(err)

            res.json(recordset);

        });
    });

};

// Update a Customer identified by the customerId in the request
exports.update = (req, res) => {
    // Validate request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    sql.connect(config, function (err) {

        if (err) console.log(err);

        var request = new sql.Request();
        var query = `UPDATE suppliers SET code = '${req.body.code}', status = '${req.body.status}', name = '${req.body.name}', arabic_name = '${req.body.arabic_name}', address = '${req.body.address}', phone = '${req.body.phone}', country_id = '${req.body.country_id}', currency_id = '${req.body.currency_id}', sales_rep_id = '${req.body.sales_rep_id}', related_party = '${req.body.related_party}', credit_limit = '${req.body.credit_limit}', vat_number = '${req.body.vat_number}' WHERE id = ${req.body.id}`;
        console.log(query);

        request.query(query, function (err, recordset) {

            if (err) console.log(err)

            res.json(recordset);

        });
    });

};


// Delete a Business Line with the specified id in the request
exports.delete = (req, res) => {

    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    sql.connect(config, function (err) {

        if (err) console.log(err);

        var request = new sql.Request();
        var query = `DELETE suppliers WHERE id = ${req.body.id}`;

        console.log(query);

        request.query(query, function (err, recordset) {

            if (err) console.log(err)

            res.json(recordset);

        });
    });

};

// const BusinessLine = require("../models/asset_groups.model");

var sql = require("mssql");
var dbConfig = require("../config/db.config");

var config = {
  user: dbConfig.USER,
  password: dbConfig.PASSWORD,
  server: dbConfig.HOST,
  database: dbConfig.DB
};


// Create and Save a new Customer
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  sql.connect(config, function (err) {

    if (err) console.log(err);

    var request = new sql.Request();
    let queryString = `INSERT INTO asset_groups VALUES ('${req.body.title}', '${req.body.description}')`;
    console.log(queryString);

    request.query(queryString, function (err, recordset) {

      if (err) console.log(err)

      res.json(recordset);

    });
  });

};

// Retrieve all Customers from the database.
exports.findAll = (req, res) => {
  sql.connect(config, function (err) {

    if (err) console.log(err);

    var request = new sql.Request();

    request.query('select * from asset_groups order by id desc', function (err, recordset) {

      if (err) console.log(err)

      res.json(recordset);

    });
  });

};

// Find a single Customer with a customerId
exports.findOne = (req, res) => {

  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  sql.connect(config, function (err) {

    if (err) console.log(err);

    var request = new sql.Request();
    var query = `SELECT * FROM asset_groups WHERE id = ${req.body.id}`;

    console.log(query);

    request.query(query, function (err, recordset) {

      if (err) console.log(err)

      res.json(recordset);

    });
  });

};

// Update a Customer identified by the customerId in the request
exports.update = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  sql.connect(config, function (err) {

    if (err) console.log(err);

    var request = new sql.Request();
    var query = `UPDATE asset_groups SET title = '${req.body.title}', description = '${req.body.description}' WHERE id = ${req.body.id}`;
    console.log(query);

    request.query(query, function (err, recordset) {

      if (err) console.log(err)

      res.json(recordset);

    });
  });

};


// Delete a Business Line with the specified id in the request
exports.delete = (req, res) => {

  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  sql.connect(config, function (err) {

    if (err) console.log(err);

    var request = new sql.Request();
    var query = `DELETE asset_groups WHERE id = ${req.body.id}`;

    console.log(query);

    request.query(query, function (err, recordset) {

      if (err) console.log(err)

      res.json(recordset);

    });
  });

};

// Delete all Customers from the database.
// exports.deleteAll = (req, res) => {
//   BusinessLine.removeAll((err, data) => {
//     if (err)
//       res.status(500).send({
//         message:
//           err.message || "Some error occurred while removing all customers."
//       });
//     else res.send({ message: `All Customers were deleted successfully!` });
//   });
// };

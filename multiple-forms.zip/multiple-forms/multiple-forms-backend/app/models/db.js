const sql = require("mssql");
const dbConfig = require("../config/db.config.js");

var config = {
  user: dbConfig.USER,
  password: dbConfig.PASSWORD,
  server: dbConfig.HOST,
  database: dbConfig.DB
};

var connection = sql.connect(config, function (err) {

  if (err) console.log(err);

  var request = new sql.Request();

  // request.query('select * from items', function (err, recordset) {

  //   if (err) console.log(err)

  //   console.log(recordset);

  // });
});


// var connection = mssql.connect(config, function (err) {

//   if (err) console.log(err);

//   // create Request object
//   var request = new mssql.Request();

//   // query to the database and get the records
//   request.query('select * from items', function (err, recordset) {

//     if (err) console.log(err)

//       // send records as a response
//       (recordset);

//   });
// });

module.exports = connection;

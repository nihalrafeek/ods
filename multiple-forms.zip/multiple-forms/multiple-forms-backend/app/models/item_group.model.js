const sql = require("./db.js");

// constructor
const ItemGroup = function(item) {
  this.title = item.title;
  this.description = item.description;
};

ItemGroup.create = (newItem, result) => {
  console.log(item); 
  sql.query("INSERT INTO item_group SET ?", newItem, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created Item Group: ", { id: res.insertId, ...newItem });
    result(null, { id: res.insertId, ...newItem });
  });
};

ItemGroup.findById = (itemId, result) => {
  sql.query(`SELECT * FROM item_group WHERE id = ${itemId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found item group: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

ItemGroup.getAll = result => {
  sql.query("SELECT * FROM item_group", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("item group: ", res);
    result(null, res);
  });
};

ItemGroup.updateById = (id, item, result) => {
  sql.query(
    "UPDATE item_group SET title = ?, description = ? WHERE id = ?",
    [ItemGroup.title, ItemGroup.description, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found item with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated item: ", { id: id, ...item });
      result(null, { id: id, ...item });
    }
  );
};

ItemGroup.remove = (id, result) => {
  sql.query("DELETE FROM item_group WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found item group with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted item group with id: ", id);
    result(null, res);
  });
};

ItemGroup.removeAll = result => {
  sql.query("DELETE FROM item_group", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} customers`);
    result(null, res);
  });
};

module.exports = ItemGroup;

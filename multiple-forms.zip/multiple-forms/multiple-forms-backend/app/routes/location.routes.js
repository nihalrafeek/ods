module.exports = app => {
    const location = require("../controllers/location.controller");
  
  
  
    // Update a Customer with customerId
    app.post("/updateLocation", location.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findLocation", location.findOne);
  
    // Create a new Customer
    app.post("/addLocation", location.create);
  
    // Retrieve all Customers
    app.post("/getAllLocations", location.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteLocation", location.delete);
  
  };
  
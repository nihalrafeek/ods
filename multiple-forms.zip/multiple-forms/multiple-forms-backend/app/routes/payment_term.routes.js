module.exports = app => {
    const payment_term = require("../controllers/payment_term.controller.js");
  
  
  
    // Update a Customer with customerId
    app.post("/updatePaymentTerm", payment_term.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findPaymentTerm", payment_term.findOne);
  
    // Create a new Customer
    app.post("/addPaymentTerm", payment_term.create);
  
    // Retrieve all Customers
    app.post("/getAllPaymentTerms", payment_term.findAll);
  
    // Delete a Customer with customerId
    app.post("/deletePaymentTerm", payment_term.delete);
  
  };
  
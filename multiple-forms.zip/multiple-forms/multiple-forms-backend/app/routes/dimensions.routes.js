module.exports = app => {
    const dimension = require("../controllers/dimension.controller.js");

    // Update a Customer with customerId
    app.post("/updateDimension", dimension.update);

    // Retrieve a single Customer with customerId
    app.post("/findDimension", dimension.findOne);

    // Create a new Customer
    app.post("/addDimension", dimension.create);

    // Retrieve all Customers
    app.post("/getAllDimensions", dimension.findAll);

    // Delete a Customer with customerId
    app.post("/deleteDimension", dimension.delete);

    // Create a new Customer
    // app.delete("/customers", dimension.deleteAll);
};

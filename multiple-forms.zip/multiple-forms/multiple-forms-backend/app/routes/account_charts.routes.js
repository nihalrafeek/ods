module.exports = app => {
    const account_chart = require("../controllers/account_chart.controller.js");
  
    // Update a Customer with customerId
    app.post("/updateChartOfAccount", account_chart.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findChartOfAccount", account_chart.findOne);
  
    // Create a new Customer
    app.post("/addChartOfAccount", account_chart.create);
  
    // Retrieve all Customers
    app.post("/getAllChartOfAccounts", account_chart.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteChartOfAccount", account_chart.delete);
  
    // Create a new Customer
    // app.delete("/customers", account_chart.deleteAll);
  };
  
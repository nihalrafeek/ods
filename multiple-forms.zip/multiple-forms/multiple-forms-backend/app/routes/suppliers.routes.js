module.exports = app => {
    const suppliers = require("../controllers/suppliers.controller.js");
  
  
  
    // Update a suppliers with suppliersId
    app.post("/updateSuppliers", suppliers.update);
  
    // Retrieve a single suppliers with suppliersId
    app.post("/findSuppliers", suppliers.findOne);
  
    // Create a new suppliers
    app.post("/addSuppliers", suppliers.create);
  
    // Retrieve all supplierss
    app.post("/getAllSuppliers", suppliers.findAll);
  
    // Delete a suppliers with suppliersId
    app.post("/deleteSuppliers", suppliers.delete);
  
  };
  
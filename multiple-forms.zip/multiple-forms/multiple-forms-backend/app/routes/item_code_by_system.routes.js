module.exports = app => {
    const item_code_by_system = require("../controllers/item_code_by_system.controller");
  
    // Update a Customer with customerId
    app.post("/updateItemCodeBySystem", item_code_by_system.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findItemCodeBySystem", item_code_by_system.findOne);
  
    // Create a new Customer
    app.post("/addItemCodeBySystem", item_code_by_system.create);
  
    // Retrieve all Customers
    app.post("/getAllItemCodeBySystem", item_code_by_system.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteItemCodeBySystem", item_code_by_system.delete);
  
    // Create a new Customer
    // app.delete("/customers", item_code_by_system.deleteAll);
  };
  
module.exports = app => {
    const delivery_term = require("../controllers/delivery_term.controller");
  
  
  
    // Update a Customer with customerId
    app.post("/updateDeliveryTerm", delivery_term.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findDeliveryTerm", delivery_term.findOne);
  
    // Create a new Customer
    app.post("/addDeliveryTerm", delivery_term.create);
  
    // Retrieve all Customers
    app.post("/getAllDeliveryTerms", delivery_term.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteDeliveryTerm", delivery_term.delete);
  
  };
  
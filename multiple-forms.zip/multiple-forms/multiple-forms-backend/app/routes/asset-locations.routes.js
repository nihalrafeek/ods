module.exports = app => {
    const asset_location = require("../controllers/asset_location.controller.js");
  
    // Update a Customer with customerId
    app.post("/updateAssetLocation", asset_location.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findAssetLocation", asset_location.findOne);
  
    // Create a new Customer
    app.post("/addAssetLocation", asset_location.create);
  
    // Retrieve all Customers
    app.post("/getAllAssetLocations", asset_location.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteAssetLocation", asset_location.delete);
  
    // Create a new Customer
    // app.delete("/customers", asset_location.deleteAll);
  };
  
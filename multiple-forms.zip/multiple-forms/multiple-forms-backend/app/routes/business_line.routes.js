module.exports = app => {
  const business_line = require("../controllers/business_line.controller.js");



  // Update a Customer with customerId
  app.post("/updateLineOfBusiness", business_line.update);

  // Retrieve a single Customer with customerId
  app.post("/findLineOfBusiness", business_line.findOne);

  // Create a new Customer
  app.post("/addLineOfBusiness", business_line.create);

  // Retrieve all Customers
  app.post("/getAllLineOfBusiness", business_line.findAll);

  // Delete a Customer with customerId
  app.post("/deleteLineOfBusiness", business_line.delete);

  // Create a new Customer
  // app.delete("/customers", business_line.deleteAll);
};

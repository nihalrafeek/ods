module.exports = app => {
    const units = require("../controllers/units.controller");
  
  
  
    // Update a Customer with customerId
    app.post("/updateUnit", units.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findUnit", units.findOne);
  
    // Create a new Customer
    app.post("/addUnit", units.create);
  
    // Retrieve all Customers
    app.post("/getAllUnits", units.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteUnit", units.delete);
  
  };
  
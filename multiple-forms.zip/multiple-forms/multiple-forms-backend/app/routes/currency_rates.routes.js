module.exports = app => {
    const currency_rate = require("../controllers/currency_rate.controller.js");
  
    // Update a Customer with customerId
    app.post("/updateCurrencyRates", currency_rate.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findCurrencyRates", currency_rate.findOne);
  
    // Create a new Customer
    app.post("/addCurrencyRates", currency_rate.create);
  
    // Retrieve all Customers
    app.post("/getAllCurrencyRates", currency_rate.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteCurrencyRates", currency_rate.delete);
  
    // Create a new Customer
    // app.delete("/customers", currency_rate.deleteAll);
  };
  
module.exports = app => {
    const asset_location = require("../controllers/asset_group.controller.js");
  
    // Update a Customer with customerId
    app.post("/updateAssetGroup", asset_location.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findAssetGroup", asset_location.findOne);
  
    // Create a new Customer
    app.post("/addAssetGroup", asset_location.create);
  
    // Retrieve all Customers
    app.post("/getAllAssetGroups", asset_location.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteAssetGroup", asset_location.delete);
  
    // Create a new Customer
    // app.delete("/customers", asset_location.deleteAll);
  };
  
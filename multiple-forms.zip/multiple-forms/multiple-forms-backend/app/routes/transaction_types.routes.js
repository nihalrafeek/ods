module.exports = app => {
    const transaction_type = require("../controllers/transaction_type.controller.js");

    // Update a Customer with customerId
    app.post("/updateTransactionType", transaction_type.update);

    // Retrieve a single Customer with customerId
    app.post("/findTransactionType", transaction_type.findOne);

    // Create a new Customer
    app.post("/addTransactionType", transaction_type.create);

    // Retrieve all Customers
    app.post("/getAllTransactionTypes", transaction_type.findAll);

    // Delete a Customer with customerId
    app.post("/deleteTransactionType", transaction_type.delete);

    // Create a new Customer
    // app.delete("/customers", transaction_type.deleteAll);
};

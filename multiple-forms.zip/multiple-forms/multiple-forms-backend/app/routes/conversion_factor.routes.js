module.exports = app => {
    const conversion_factor = require("../controllers/conversion_factor.controller");
  
  
  
    // Update a Customer with customerId
    app.post("/updateConFactor", conversion_factor.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findConFactor", conversion_factor.findOne);
  
    // Create a new Customer
    app.post("/addConFactor", conversion_factor.create);
  
    // Retrieve all Customers
    app.post("/getAllConFactor", conversion_factor.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteConFactor", conversion_factor.delete);
  
  };
  
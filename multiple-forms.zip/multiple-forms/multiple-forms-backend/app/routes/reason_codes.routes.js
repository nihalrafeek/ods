module.exports = app => {
    const reason_codes = require("../controllers/reason_codes.controller.js");
  
  
  
    // Update a Customer with customerId
    app.post("/updateReasonCode", reason_codes.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findReasonCode", reason_codes.findOne);
  
    // Create a new Customer
    app.post("/addReasonCode", reason_codes.create);
  
    // Retrieve all Customers
    app.post("/getAllReasonCodes", reason_codes.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteReasonCode", reason_codes.delete);
  
  };
  
module.exports = app => {
    const free_number = require("../controllers/free_number.controller");
  
  
  
    // Update a Customer with customerId
    app.post("/updateFreeNumber", free_number.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findFreeNumber", free_number.findOne);
  
    // Create a new Customer
    app.post("/addFreeNumber", free_number.create);
  
    // Retrieve all Customers
    app.post("/getAllFreeNumber", free_number.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteFreeNumber", free_number.delete);
  
  };
  
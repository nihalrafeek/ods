module.exports = app => {
  const employees = require("../controllers/empoyee.controller");



  // Update a Customer with customerId
  app.post("/updateEmployee", employees.update);

  // Retrieve a single Customer with customerId
  app.post("/findEmployee", employees.findOne);

  // Create a new Customer
  app.post("/addEmployee", employees.create);

  // Retrieve all Customers
  app.post("/getAllEmployee", employees.findAll);

  // Delete a Customer with customerId
  app.post("/deleteEmployee", employees.delete);

};

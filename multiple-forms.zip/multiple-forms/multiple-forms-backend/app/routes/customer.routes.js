module.exports = app => {
    const customer = require("../controllers/customer.controller.js");
  
  
  
    // Update a Customer with customerId
    app.post("/updateCustomer", customer.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findCustomer", customer.findOne);
  
    // Create a new Customer
    app.post("/addCustomer", customer.create);
  
    // Retrieve all Customers
    app.post("/getAllCustomers", customer.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteCustomer", customer.delete);
  
    // Create a new Customer
    // app.delete("/customers", customer.deleteAll);
  };
  
module.exports = app => {
    const product_type = require("../controllers/product_type.controller.js");
  
  
  
    // Update a Customer with customerId
    app.post("/updateProductType", product_type.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findProductType", product_type.findOne);
  
    // Create a new Customer
    app.post("/addProductType", product_type.create);
  
    // Retrieve all Customers
    app.post("/getAllProductType", product_type.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteProductType", product_type.delete);
  
  };
  
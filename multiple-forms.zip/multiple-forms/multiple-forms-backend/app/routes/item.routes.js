module.exports = app => {
    const item = require("../controllers/item.controller");
  
  
  
    // Update a Customer with customerId
    app.post("/updateItem", item.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findItem", item.findOne);
  
    // Create a new Customer
    app.post("/addItem", item.create);
  
    // Retrieve all Customers
    app.post("/getAllItems", item.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteItem", item.delete);
  
  };
  
module.exports = app => {
    const warehouse = require("../controllers/warehouse.controller");
  
  
  
    // Update a Customer with customerId
    app.post("/updateWarehouse", warehouse.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findWarehouse", warehouse.findOne);
  
    // Create a new Customer
    app.post("/addWarehouse", warehouse.create);
  
    // Retrieve all Customers
    app.post("/getAllWarehouse", warehouse.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteWarehouse", warehouse.delete);
  
  };
  
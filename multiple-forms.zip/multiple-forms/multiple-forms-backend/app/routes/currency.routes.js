module.exports = app => {
    const currency = require("../controllers/currency.controller");
  
  
  
    // Update a Customer with customerId
    app.post("/updateCurrency", currency.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findCurrency", currency.findOne);
  
    // Create a new Customer
    app.post("/addCurrency", currency.create);
  
    // Retrieve all Customers
    app.post("/getAllCurrency", currency.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteCurrency", currency.delete);
  
  };
  
module.exports = app => {
    const product_line = require("../controllers/product_line.controller.js");
  
  
  
    // Update a Customer with customerId
    app.post("/updateProductLine", product_line.update);
  
    // Retrieve a single Customer with customerId
    app.post("/findProductLine", product_line.findOne);
  
    // Create a new Customer
    app.post("/addProductLine", product_line.create);
  
    // Retrieve all Customers
    app.post("/getAllProductLine", product_line.findAll);
  
    // Delete a Customer with customerId
    app.post("/deleteProductLine", product_line.delete);
  
  };
  
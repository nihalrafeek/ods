module.exports = app => {
    const period = require("../controllers/period.controller.js");

    // Update a Customer with customerId
    app.post("/updatePeriod", period.update);

    // Retrieve a single Customer with customerId
    app.post("/findPeriod", period.findOne);

    // Create a new Customer
    app.post("/addPeriod", period.create);

    // Retrieve all Customers
    app.post("/getAllPeriods", period.findAll);

    // Delete a Customer with customerId
    app.post("/deletePeriod", period.delete);

};

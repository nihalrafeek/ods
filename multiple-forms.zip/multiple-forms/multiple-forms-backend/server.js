const express = require("express");
const bodyParser = require("body-parser");

const app = express();
var sql = require("mssql");

var config = {
  user: 'sa',
  password: 'tiger',
  server: 'localhost',
  database: 'multiple_forms'
};

// parse requests of content-type - application/json
app.use(bodyParser.json());

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

app.use(function (req, res, next) {

  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin', '*');

  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader('Access-Control-Allow-Credentials', true);

  // Pass to next layer of middleware
  next();
});


// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to nodejs application." });
});

require("./app/routes/business_line.routes.js")(app);
require("./app/routes/employees.routes.js")(app);
require("./app/routes/item_code_by_system.routes.js")(app);
require("./app/routes/free_number.routes.js")(app);
require("./app/routes/conversion_factor.routes.js")(app);
require("./app/routes/units.routes.js")(app);
require("./app/routes/location.routes.js")(app);
require("./app/routes/reason_codes.routes.js")(app);
require("./app/routes/warehouse.routes.js")(app);
require("./app/routes/currency.routes.js")(app);
require("./app/routes/payment_term.routes.js")(app);
require("./app/routes/delivery_term.routes.js")(app);
require("./app/routes/product_type.routes.js")(app);
require("./app/routes/product_line.routes.js")(app);
require("./app/routes/item.routes.js")(app);
require("./app/routes/customer.routes.js")(app);
require("./app/routes/asset-locations.routes.js")(app);
require("./app/routes/asset-groups.routes.js")(app);
require("./app/routes/dimensions.routes.js")(app);
require("./app/routes/suppliers.routes.js")(app);
require("./app/routes/account_charts.routes.js")(app);
require("./app/routes/transaction_types.routes.js")(app);
require("./app/routes/currency_rates.routes.js")(app);
require("./app/routes/periods.routes.js")(app);


// set port, listen for requests
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});



//working fine

// app.get('/', function (req, res) {

//   var sql = require("mssql");

//   var config = {
//       user: 'sa',
//       password: 'tiger',
//       server: 'localhost', 
//       database: 'multiple_forms' 
//   };

//   sql.connect(config, function (err) {

//       if (err) console.log(err);

//       var request = new sql.Request();

//       request.query('select * from items', function (err, recordset) {

//           if (err) console.log(err)

//           res.json(recordset);

//       });
//   });
// });



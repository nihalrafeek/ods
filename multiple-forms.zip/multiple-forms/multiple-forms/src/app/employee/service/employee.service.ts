import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllEmployee() {
    return this.http.post(`${this.url}/getAllEmployee`, []);
  }

  findEmployee(id) {
    return this.http.post(`${this.url}/findEmployee`, { id: id });
  }

  addEmployee(item) {
    return this.http.post(`${this.url}/addEmployee`, item);
  }

  updateEmployee(item) {
    return this.http.post(`${this.url}/updateEmployee`, item);
  }

  deleteEmployee(id) {
    return this.http.post(`${this.url}/deleteEmployee`, { id: id });
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversionFactorComponent } from './conversion-factor.component';

describe('ConversionFactorComponent', () => {
  let component: ConversionFactorComponent;
  let fixture: ComponentFixture<ConversionFactorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConversionFactorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversionFactorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

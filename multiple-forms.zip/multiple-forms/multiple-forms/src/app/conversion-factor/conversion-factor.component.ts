import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ButtonRendererComponent } from './../renderer/button-renderer.component';
import { NgbModal, ModalDismissReasons, NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ConversionFactorService } from './service/conversion-factor.service';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { GridOptions } from 'ag-grid-community';


@Component({
  selector: 'app-conversion-factor',
  templateUrl: './conversion-factor.component.html',
  styleUrls: ['./conversion-factor.component.scss']
})
export class ConversionFactorComponent implements OnInit {

  closeResult = '';
  frameworkComponents: any;
  isEdit: boolean;
  staticAlertClosed = false;
  successMessage = '';
  conFactorId: number;
  private _success = new Subject<string>();
  itemToBeDeleted;
  paginationPageSize;
  searchText;

  @ViewChild('content', { static: false }) private content;
  @ViewChild('confirmModel', { static: false }) private confirmModel;
  @ViewChild('staticAlert', { static: false }) staticAlert: NgbAlert;
  @ViewChild('selfClosingAlert', { static: false }) selfClosingAlert: NgbAlert;


  conversion_factors = { item: '', base_unit: '', unit: '', conversion_factor: 0, rise_10_to_the_power: 0, id: 0 };
  formModalReference;
  submitted = false;
  form = new FormGroup({
    item: new FormControl('', Validators.required),
    base_unit: new FormControl('', Validators.required),
    unit: new FormControl('', Validators.required),
    conversion_factor: new FormControl('', Validators.required),
    rise_10_to_the_power: new FormControl('', Validators.required)
  });

  hashValueGetter = function (params) {
    return ++params.node.rowIndex;
  };

  columnDefs = [
    {
      headerName: 'Sno', field: 'title', maxWidth: 100, resizable: true, valueGetter: this.hashValueGetter,
    },
    {
      headerName: 'Item', field: 'item', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Base Unit', field: 'base_unit', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Unit', field: 'unit', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Conversion Factor', field: 'conversion_factor', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Rise 10 To The Power', field: 'rise_10_to_the_power', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Action',
      width: 90,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.onBtnClick.bind(this),
        // label: 'Edit',
        icon: 'fa fa-edit'
      }
    },
    {
      headerName: '',
      width: 110,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.deleteItem.bind(this),
        // label: 'Delete',
        icon: 'fa fa-trash'
      }
    },
  ];

  rowData = [
  ];

  gridOptions: GridOptions = {
    columnDefs: this.columnDefs,
    rowData: null,
    getRowStyle: this.getRowStyleScheduled
  };
  gridApi: any;
  gridColumnApi: any;
  rowClassRules: any;
  inValidRowNode: boolean;

  constructor(private modalService: NgbModal, private formBuilder: FormBuilder, private conversionFactorService: ConversionFactorService) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.isEdit = false;
    if (this.staticAlert) {
      setTimeout(() => this.staticAlert.close(), 20000);
    }
    this._success.subscribe(message => this.successMessage = message);
    this._success.pipe(debounceTime(5000)).subscribe(() => {
      if (this.selfClosingAlert) {
        this.selfClosingAlert.close();
      }
    });
    // this.getAllConFactor();
    this.paginationPageSize = 10;
  }

  getRowStyleScheduled(params) {
    if (params.node.rowIndex % 2 == 0) {
      return {
        'background-color': 'rgba(0,0,0,.05)',
      }
    }
    return null;
  };


  get f() { return this.form.controls; }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onSubmit() {
    this.submitted = true;
    let close: any = document.querySelector('#closeForm');
    if (this.form.invalid) {
      return;
    }
    else {
      this.conversion_factors.item = this.conversion_factors.item.trim();
      this.conversion_factors.base_unit = this.conversion_factors.base_unit.trim();
      this.conversion_factors.unit = this.conversion_factors.unit.trim();
      if (!this.isEdit) {
        this.conversionFactorService.addConFactor(this.conversion_factors).subscribe((res) => {
          console.log(res);
          close.click();
          this.conFactorId = 0;
          this.submitted = false;
          this._success.next(`Data Saved Successfully`);
          this.getAllConFactor();
        });
      }
      else {
        this.conversionFactorService.updateConFactor(this.conversion_factors).subscribe((res: any) => {
          this.isEdit = false;
          if (res && res.rowsAffected) {
            this.submitted = false;
            close.click();
            this._success.next(`Data Updated Successfully`);
            this.getAllConFactor();
          }
        });
      }
      this.conversion_factors = { item: '', base_unit: '', unit: '', conversion_factor: 0, rise_10_to_the_power: 0, id: 0 };
    }
  }


  onBtnClick(row) {
    this.isEdit = true;
    this.conFactorId = row.rowData.id;
    this.conversionFactorService.findConFactor(this.conFactorId).subscribe((res: any) => {
      this.conversion_factors.id = this.conFactorId;
      this.conversion_factors = res.recordset[0];

    })
    this.open(this.content);
  }

  deleteItem(row) {
    this.conFactorId = row.rowData.id;
    this.itemToBeDeleted = row.rowData.title;
    this.open(this.confirmModel);
  }

  deleteClose() {

    let closeDel: any = document.querySelector('#closeDel');
    this.conversionFactorService.deleteConFactor(this.conFactorId).subscribe((res) => {
      closeDel.click();
      this._success.next(`Deleted Successfully`);
      this.getAllConFactor();
    })
  }

  getAllConFactor() {
    this.conversionFactorService.getAllConFactor().subscribe((res: any) => {
      this.rowData = res.recordset;
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.conversionFactorService.getAllConFactor().subscribe((res: any) => {
      params.api.setRowData(res.recordset)
    })
  }

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchText);
  }


}

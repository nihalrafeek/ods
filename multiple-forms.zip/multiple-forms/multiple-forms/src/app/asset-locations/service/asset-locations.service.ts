import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AssetLocationsService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllAssetLocations() {
    return this.http.post(`${this.url}/getAllAssetLocations`, []);
  }

  findAssetLocation(id) {
    return this.http.post(`${this.url}/findAssetLocation`, { id: id });
  }

  addAssetLocation(item) {
    return this.http.post(`${this.url}/addAssetLocation`, item);
  }

  updateAssetLocation(item) {
    return this.http.post(`${this.url}/updateAssetLocation`, item);
  }

  deleteAssetLocation(id) {
    return this.http.post(`${this.url}/deleteAssetLocation`, { id: id });
  }

}

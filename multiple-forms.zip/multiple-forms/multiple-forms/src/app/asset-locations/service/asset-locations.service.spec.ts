import { TestBed } from '@angular/core/testing';

import { AssetLocationsService } from './asset-locations.service';

describe('AssetLocationsService', () => {
  let service: AssetLocationsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssetLocationsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

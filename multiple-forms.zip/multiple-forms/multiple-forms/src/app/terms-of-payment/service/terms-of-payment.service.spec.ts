import { TestBed } from '@angular/core/testing';

import { TermsOfPaymentService } from './terms-of-payment.service';

describe('TermsOfPaymentService', () => {
  let service: TermsOfPaymentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TermsOfPaymentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

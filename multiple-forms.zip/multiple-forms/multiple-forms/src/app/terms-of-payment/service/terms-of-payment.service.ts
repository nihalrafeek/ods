import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TermsOfPaymentService {
  url: string;

  constructor(public http: HttpClient) {
    this.url = environment.API_URL;
  }

  getAllPaymentTerms() {
    return this.http.post(`${this.url}/getAllPaymentTerms`, []);
  }

  findPaymentTerm(id) {
    return this.http.post(`${this.url}/findPaymentTerm`, { id: id });
  }

  addPaymentTerm(item) {
    return this.http.post(`${this.url}/addPaymentTerm`, item);
  }

  updatePaymentTerm(item) {
    return this.http.post(`${this.url}/updatePaymentTerm`, item);
  }

  deletePaymentTerm(id) {
    return this.http.post(`${this.url}/deletePaymentTerm`, { id: id });
  }

}

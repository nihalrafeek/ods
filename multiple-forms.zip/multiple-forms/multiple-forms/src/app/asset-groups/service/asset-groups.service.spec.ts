import { TestBed } from '@angular/core/testing';

import { AssetGroupsService } from './asset-groups.service';

describe('AssetGroupsService', () => {
  let service: AssetGroupsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssetGroupsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AssetGroupsService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllAssetGroups() {
    return this.http.post(`${this.url}/getAllAssetGroups`, []);
  }

  findAssetGroup(id) {
    return this.http.post(`${this.url}/findAssetGroup`, { id: id });
  }

  addAssetGroup(item) {
    return this.http.post(`${this.url}/addAssetGroup`, item);
  }

  updateAssetGroup(item) {
    return this.http.post(`${this.url}/updateAssetGroup`, item);
  }

  deleteAssetGroup(id) {
    return this.http.post(`${this.url}/deleteAssetGroup`, { id: id });
  }

}

import { Component, OnInit, ViewChild } from '@angular/core';
import { ButtonRendererComponent } from './../renderer/button-renderer.component';
import { NgbModal, ModalDismissReasons, NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AssetGroupsService } from './service/asset-groups.service';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { GridOptions } from 'ag-grid-community';

@Component({
  selector: 'app-asset-groups',
  templateUrl: './asset-groups.component.html',
  styleUrls: ['./asset-groups.component.scss']
})
export class AssetGroupsComponent implements OnInit {

  closeResult = '';
  frameworkComponents: any;
  isEdit: boolean;
  staticAlertClosed = false;
  successMessage = '';
  assetLocationId: number;
  private _success = new Subject<string>();
  itemToBeDeleted;
  paginationPageSize;
  searchText;

  @ViewChild('content', { static: false }) private content;
  @ViewChild('confirmModel', { static: false }) private confirmModel;
  @ViewChild('staticAlert', { static: false }) staticAlert: NgbAlert;
  @ViewChild('selfClosingAlert', { static: false }) selfClosingAlert: NgbAlert;


  asset_group = { title: '', description: '', id: 0 };
  formModalReference;
  submitted = false;
  form = new FormGroup({
    title: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required)
  });

  hashValueGetter = function (params) {
    return ++params.node.rowIndex;
  };

  columnDefs = [
    {
      headerName: 'Sno', field: '', maxWidth: 100, valueGetter: this.hashValueGetter,
    },
    {
      headerName: 'Main Groups', field: 'title', width: 250, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Description', field: 'description', width: 510, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Action',
      width: 90,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.onBtnClick.bind(this),
        // label: 'Edit',
        icon: 'fa fa-edit'
      }
    },
    {
      headerName: '',
      width: 110,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.deleteItem.bind(this),
        // label: 'Delete',
        icon: 'fa fa-trash'
      }
    },
  ];

  rowData = [
  ];

  gridOptions: GridOptions = {
    columnDefs: this.columnDefs,
    rowData: null,
    getRowStyle: this.getRowStyleScheduled
  };
  gridApi: any;
  gridColumnApi: any;
  rowClassRules: any;
  inValidRowNode: boolean;

  constructor(private modalService: NgbModal, private formBuilder: FormBuilder, private assetGroupsService: AssetGroupsService) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.isEdit = false;
    if (this.staticAlert) {
      setTimeout(() => this.staticAlert.close(), 20000);
    }
    this._success.subscribe(message => this.successMessage = message);
    this._success.pipe(debounceTime(5000)).subscribe(() => {
      if (this.selfClosingAlert) {
        this.selfClosingAlert.close();
      }
    });
    // this.getAllAssetGroups();
    this.paginationPageSize = 10;
  }

  getRowStyleScheduled(params) {
    if (params.node.rowIndex % 2 == 0) {
      return {
        'background-color': 'rgba(0,0,0,.05)',
      }
    }
    return null;
  };


  get f() { return this.form.controls; }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onSubmit() {
    this.submitted = true;
    let close: any = document.querySelector('#closeForm');
    if (this.form.invalid) {
      return;
    }
    else {
      this.asset_group.title = this.asset_group.title.trim();
      this.asset_group.description = this.asset_group.description.trim();

      if (!this.isEdit) {
        this.assetGroupsService.addAssetGroup(this.asset_group).subscribe((res) => {
          console.log(res);
          close.click();
          this.assetLocationId = 0;
          this.submitted = false;
          this._success.next(`Data Saved Successfully`);
          this.getAllAssetGroups();
        });
      }
      else {
        this.assetGroupsService.updateAssetGroup(this.asset_group).subscribe((res: any) => {
          this.isEdit = false;
          if (res && res.rowsAffected) {
            this.submitted = false;
            close.click();
            this._success.next(`Data Updated Successfully`);
            this.getAllAssetGroups();
          }
        });
      }
      this.asset_group = { title: '', description: '', id: 0 };
    }
  }


  onBtnClick(row) {
    this.isEdit = true;
    this.assetLocationId = row.rowData.id;
    this.assetGroupsService.findAssetGroup(this.assetLocationId).subscribe((res: any) => {
      this.asset_group.id = this.assetLocationId;
      this.asset_group = res.recordset[0];
    })
    this.open(this.content);
  }

  deleteItem(row) {
    this.assetLocationId = row.rowData.id;
    this.itemToBeDeleted = row.rowData.title;
    this.open(this.confirmModel);
  }

  deleteClose() {

    let closeDel: any = document.querySelector('#closeDel');
    this.assetGroupsService.deleteAssetGroup(this.assetLocationId).subscribe((res) => {
      closeDel.click();
      this._success.next(`Deleted Successfully`);
      this.getAllAssetGroups();
    })
  }

  getAllAssetGroups() {
    this.assetGroupsService.getAllAssetGroups().subscribe((res: any) => {
      this.rowData = res.recordset;
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.assetGroupsService.getAllAssetGroups().subscribe((res: any) => {
      params.api.setRowData(res.recordset)
    })
  }

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchText);
  }

}

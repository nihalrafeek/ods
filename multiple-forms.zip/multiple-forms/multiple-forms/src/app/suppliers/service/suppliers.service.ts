import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SuppliersService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllSuppliers() {
    return this.http.post(`${this.url}/getAllSuppliers`, []);
  }

  findSuppliers(id) {
    return this.http.post(`${this.url}/findSuppliers`, { id: id });
  }

  addSuppliers(item) {
    return this.http.post(`${this.url}/addSuppliers`, item);
  }

  updateSuppliers(item) {
    return this.http.post(`${this.url}/updateSuppliers`, item);
  }

  deleteSuppliers(id) {
    return this.http.post(`${this.url}/deleteSuppliers`, { id: id });
  }

}

import { Component, OnInit, ViewChild } from '@angular/core';
import { ButtonRendererComponent } from './../renderer/button-renderer.component';
import { NgbModal, ModalDismissReasons, NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SuppliersService } from './service/suppliers.service';
import { CurrenciesService } from '../currencies/service/currencies.service';
import {Subject} from 'rxjs';
import {debounceTime} from 'rxjs/operators';
import { GridOptions } from 'ag-grid-community';

@Component({
  selector: 'app-suppliers',
  templateUrl: './suppliers.component.html',
  styleUrls: ['./suppliers.component.scss']
})
export class SuppliersComponent implements OnInit {

  closeResult = '';
  frameworkComponents: any;
  isEdit: boolean;
  staticAlertClosed = false;
  successMessage = '';
  itemGroupId: number;
  private _success = new Subject<string>();
  itemToBeDeleted;
  paginationPageSize;
  searchText;

  country_list: any = [{ id: 1, title: "India" }, { id: 2, title: "UK" }, { id: 3, title: "USA" }];
  state_list: any = [{ id: 1, title: "Tamil Nadu" }, { id: 2, title: "Delhi" }, { id: 3, title: "Mumbai" }];
  city_list: any = [{ id: 1, title: "Trichy" }, { id: 2, title: "Chennai" }, { id: 3, title: "Madurai" }];
  currency_list;

  @ViewChild('content', { static: false }) private content;
  @ViewChild('confirmModel', { static: false }) private confirmModel;
  @ViewChild('staticAlert', { static: false }) staticAlert: NgbAlert;
  @ViewChild('selfClosingAlert', { static: false }) selfClosingAlert: NgbAlert;


  suppliers = { code: '', status: '', name: '', arabic_name:'', address:'', phone: 0, country_id: '', state_id: '', city_id: '', currency_id: '', sales_rep_id:'', related_party:'', credit_limit: 0, vat_number:'', id: 0 };
  formModalReference;
  submitted = false;
  form = new FormGroup({ 
    code: new FormControl('', Validators.required),
    status: new FormControl('', Validators.required),
    name: new FormControl('', Validators.required),
    arabic_name: new FormControl('', Validators.required),
    address: new FormControl('', Validators.required),
    phone: new FormControl('', Validators.required),
    country: new FormControl('', Validators.required),
    state: new FormControl('', Validators.required),
    city: new FormControl('', Validators.required),
    currency: new FormControl('', Validators.required),
    sales_rep: new FormControl('', Validators.required),
    related_party: new FormControl('', Validators.required),
    credit_limit: new FormControl('', Validators.required),
    vat_number: new FormControl('', Validators.required)
  });

  hashValueGetter = function (params) {
    return ++params.node.rowIndex;
  };
 
  columnDefs = [
    {
      headerName: 'Sno', field: 'title', maxWidth: 100, valueGetter: this.hashValueGetter,
    },
    {
      headerName: 'Supplier Code', field: 'code', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Supplier Status', field: 'status', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Name', field: 'name', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    }, 
    {
      headerName: 'Arabic Name', field: 'arabic_name', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Address', field: 'address', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Phone', field: 'phone', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Country', field: 'country_id', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'State', field: 'state_id', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'City', field: 'city_id', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Currency', field: 'currency_id', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Sales Reference', field: 'sales_rep_id', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    }, 
    {
      headerName: 'Supplier Related Party', field: 'related_party', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Credit Limt', field: 'credit_limit', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    }, 
    {
      headerName: 'Vat Number', field: 'vat_number', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Action',
      width: 90,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.onBtnClick.bind(this),
        // label: 'Edit',
        icon: 'fa fa-edit'
      }
    },
    {
      headerName: '',
      width: 110,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.deleteItem.bind(this),
        // label: 'Delete',
        icon: 'fa fa-trash'
      }
    },
  ];

  rowData = [
  ];

  gridOptions: GridOptions = {
    columnDefs: this.columnDefs,
    rowData: null,
    getRowStyle: this.getRowStyleScheduled
  };
  gridApi: any;
  gridColumnApi: any;
  rowClassRules: any;
  inValidRowNode: boolean;

  constructor(private modalService: NgbModal, private suppliersService: SuppliersService, private currencyService: CurrenciesService,) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.isEdit = false;
    if (this.staticAlert) {
      setTimeout(() => this.staticAlert.close(), 20000);
    }
    this._success.subscribe(message => this.successMessage = message);
    this._success.pipe(debounceTime(5000)).subscribe(() => {
      if (this.selfClosingAlert) {
        this.selfClosingAlert.close();
      }
    });
    this.getCurrencyList();
    this.paginationPageSize = 10;
  }

  getCurrencyList() {
    this.currencyService.getAllCurrency().subscribe((res: any) => {
      this.currency_list = res.recordset;
    });
  }

  getRowStyleScheduled(params) {
    if (params.node.rowIndex % 2 == 0) {
      return {
        'background-color': 'rgba(0,0,0,.05)',
      }
    }
    return null;
  };


  get f() { return this.form.controls; }

  open(content) {
    this.modalService.open(content, {size: 'lg', ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onSubmit() {
    this.submitted = true;
    let close: any = document.querySelector('#closeForm');
    if (this.form.invalid) {
      return;
    }
    else {
      this.suppliers.code = this.suppliers.code.trim();
      this.suppliers.name = this.suppliers.name.trim();
      this.suppliers.arabic_name = this.suppliers.arabic_name.trim();
      this.suppliers.address = this.suppliers.address.trim();
      this.suppliers.vat_number = this.suppliers.vat_number.trim();
      if (!this.isEdit) {
        this.suppliersService.addSuppliers(this.suppliers).subscribe((res) => {
          console.log(res);
          close.click();
          this.itemGroupId = 0;
          this.submitted = false;
          this._success.next(`Data Saved Successfully`);
          this.getAllSuppliers();
        });
      }
      else {
        this.suppliersService.updateSuppliers(this.suppliers).subscribe((res: any) => {
          this.isEdit = false;
          if (res && res.rowsAffected) {
            this.submitted = false;
            close.click();
            this._success.next(`Data Updated Successfully`);
            this.getAllSuppliers();
          }
        });
      }
      this.suppliers = { code: '', status: '', name: '', arabic_name:'', address:'', phone: 0, country_id: '', state_id: '', city_id: '', currency_id: '', sales_rep_id:'', related_party:'', credit_limit: 0, vat_number:'', id: 0 };
    }
  }


  onBtnClick(row) {
    this.isEdit = true;
    this.itemGroupId = row.rowData.id;
    this.suppliersService.findSuppliers(this.itemGroupId).subscribe((res: any) => {
      this.suppliers.id = this.itemGroupId;
      this.suppliers = res.recordset[0];
    })
    this.open(this.content);
  }

  deleteItem(row) {
    this.itemGroupId = row.rowData.id;
    this.itemToBeDeleted = row.rowData.title;
    this.open(this.confirmModel);
  }

  deleteClose() {

    let closeDel: any = document.querySelector('#closeDel');
    this.suppliersService.deleteSuppliers(this.itemGroupId).subscribe((res) => {
      closeDel.click();
      this._success.next(`Deleted Successfully`);
      this.getAllSuppliers();
    })
  }

  getAllSuppliers() {
    this.suppliersService.getAllSuppliers().subscribe((res: any) => {
      this.rowData = res.recordset;
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.suppliersService.getAllSuppliers().subscribe((res: any) => {
      params.api.setRowData(res.recordset)
    })
  }

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchText);
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LocationService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllLocations() {
    return this.http.post(`${this.url}/getAllLocations`, []);
  }

  findLocation(id) {
    return this.http.post(`${this.url}/findLocation`, { id: id });
  }

  addLocation(item) {
    return this.http.post(`${this.url}/addLocation`, item);
  }

  updateLocation(item) {
    return this.http.post(`${this.url}/updateLocation`, item);
  }

  deleteLocation(id) {
    return this.http.post(`${this.url}/deleteLocation`, { id: id });
  }
onstructor() { }
}

import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  menuItems = [
    { path: 'item-group', title: 'Item Group', icon: 'nc-bank', class: '' },
    { path: 'product-line', title: 'Product Line', icon: 'nc-diamond', class: '' },
    { path: 'product-type', title: 'Product Type', icon: 'nc-bank', class: '' },
    { path: 'warehouse', title: 'Warehouses', icon: 'nc-pin-3', class: '' },
    { path: 'terms-of-delivery', title: 'Terms of Delivery', icon: 'nc-bell-55', class: '' },
    { path: 'terms-of-payment', title: 'Terms of Payment', icon: 'nc-bell-55', class: '' },
    { path: 'currencies', title: 'Currencies', icon: 'nc-bank', class: '' },
    { path: 'reason-codes', title: 'Reason Codes', icon: 'nc-bank', class: '' },
    { path: 'location', title: 'Location', icon: 'nc-bank', class: '' },
    { path: 'units', title: 'Units', icon: 'nc-bank', class: '' },
    { path: 'conversion-factor', title: 'Conversion Factor', icon: 'nc-bank', class: '' },
    { path: 'first-free-number', title: 'First Free Number', icon: 'nc-bank', class: '' },
    { path: 'item-code-system', title: 'Item Code By System', icon: 'nc-bank', class: '' },
    { path: 'line-of-business', title: 'Line Of Business', icon: 'nc-bank', class: '' },
    { path: 'employee', title: 'Employee', icon: 'nc-bank', class: '' },
    { path: 'customers', title: 'Customers', icon: 'nc-bank', class: '' },
    { path: 'suppliers', title: 'Suppliers', icon: 'nc-bank', class: '' },
    { path: 'asset-locations', title: 'Asset Locations', icon: 'nc-bank', class: '' },
    { path: 'asset-groups', title: 'Asset Groups', icon: 'nc-bank', class: '' },
    { path: 'dimension', title: 'Dimension', icon: 'nc-bank', class: '' },
    { path: 'chart-of-accounts', title: 'Chart Of Accounts', icon: 'nc-bank', class: '' },
    { path: 'transaction-type', title: 'Transaction Type', icon: 'nc-bank', class: '' },
    { path: 'currency-rates', title: 'Currency Rates', icon: 'nc-bank', class: '' },
    { path: 'periods', title: 'Periods', icon: 'nc-bank', class: '' },
    { path: 'item-data', title: 'Item Data', icon: 'nc-bank', class: '' },
    { path: 'assets', title: 'Assets', icon: 'nc-bank', class: '' },
    { path: 'depreciation', title: 'Depreciation', icon: 'nc-bank', class: '' },
    { path: 'sales-orders', title: 'Sales Orders', icon: 'nc-bank', class: '' },
    { path: 'purchase-orders', title: 'Purchase Orders', icon: 'nc-bank', class: '' },
    { path: 'sales-contracts', title: 'Sales Contracts', icon: 'nc-bank', class: '' },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}

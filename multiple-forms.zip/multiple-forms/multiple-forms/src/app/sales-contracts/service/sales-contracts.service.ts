import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SalesContractsService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllSalesContracts() {
    return this.http.post(`${this.url}/getAllSalesContracts`, []);
  }

  findSalesContract(id) {
    return this.http.post(`${this.url}/findSalesContract`, { id: id });
  }

  addSalesContract(item) {
    return this.http.post(`${this.url}/addSalesContract`, item);
  }

  updateSalesContract(item) {
    return this.http.post(`${this.url}/updateSalesContract`, item);
  }

  deleteSalesContract(id) {
    return this.http.post(`${this.url}/deleteSalesContract`, { id: id });
  }

}

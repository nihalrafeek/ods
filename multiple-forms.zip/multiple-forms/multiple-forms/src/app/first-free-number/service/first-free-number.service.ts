import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FirstFreeNumberService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllFreeNumber() {
    return this.http.post(`${this.url}/getAllFreeNumber`, []);
  }

  findFreeNumber(id) {
    return this.http.post(`${this.url}/findFreeNumber`, { id: id });
  }

  addFreeNumber(item) {
    return this.http.post(`${this.url}/addFreeNumber`, item);
  }

  updateFreeNumber(item) {
    return this.http.post(`${this.url}/updateFreeNumber`, item);
  }

  deleteFreeNumber(id) {
    return this.http.post(`${this.url}/deleteFreeNumber`, { id: id });
  }

}

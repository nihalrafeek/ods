import { TestBed } from '@angular/core/testing';

import { FirstFreeNumberService } from './first-free-number.service';

describe('FirstFreeNumberService', () => {
  let service: FirstFreeNumberService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FirstFreeNumberService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstFreeNumberComponent } from './first-free-number.component';

describe('FirstFreeNumberComponent', () => {
  let component: FirstFreeNumberComponent;
  let fixture: ComponentFixture<FirstFreeNumberComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FirstFreeNumberComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstFreeNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

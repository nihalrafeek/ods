import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PeriodsService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllPeriods() {
    return this.http.post(`${this.url}/getAllPeriods`, []);
  }

  findPeriod(id) {
    return this.http.post(`${this.url}/findPeriod`, { id: id });
  }

  addPeriod(item) {
    return this.http.post(`${this.url}/addPeriod`, item);
  }

  updatePeriod(item) {
    return this.http.post(`${this.url}/updatePeriod`, item);
  }

  deletePeriod(id) {
    return this.http.post(`${this.url}/deletePeriod`, { id: id });
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AssetsService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllAssets() {
    return this.http.post(`${this.url}/getAllAssets`, []);
  }

  findAssets(id) {
    return this.http.post(`${this.url}/findAssets`, { id: id });
  }

  addAssets(item) {
    return this.http.post(`${this.url}/addAssets`, item);
  }

  updateAssets(item) {
    return this.http.post(`${this.url}/updateAssets`, item);
  }

  deleteAssets(id) {
    return this.http.post(`${this.url}/deleteAssets`, { id: id });
  }
}

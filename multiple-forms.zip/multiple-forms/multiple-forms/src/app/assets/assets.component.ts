import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ButtonRendererComponent } from './../renderer/button-renderer.component';
import { NgbModal, ModalDismissReasons, NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AssetsService } from './service/assets.service';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { GridOptions } from 'ag-grid-community';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-assets',
  templateUrl: './assets.component.html',
  styleUrls: ['./assets.component.scss'],
  providers: [DatePipe]
})
export class AssetsComponent implements OnInit {

  closeResult = '';
  frameworkComponents: any;
  isEdit: boolean;
  staticAlertClosed = false;
  successMessage = '';
  assetsId: number; 
  private _success = new Subject<string>();
  itemToBeDeleted;
  paginationPageSize;
  searchText;

  @ViewChild('content', { static: false }) private content;
  @ViewChild('confirmModel', { static: false }) private confirmModel;
  @ViewChild('staticAlert', { static: false }) staticAlert: NgbAlert;
  @ViewChild('selfClosingAlert', { static: false }) selfClosingAlert: NgbAlert;


  assets = { fixed_asset: '', asset_serial_number: '', description:'', fixed_asset_group:'',location: '', person_responsible: 0, purchase_value: 0 , number_of_years_in_use: 0 ,order_date: '', date_of_first_use: '', date_of_last_use:'',  id: 0 };

  formModalReference;
  submitted = false;
  form = new FormGroup({
    fixed_asset: new FormControl('', Validators.required),
    asset_serial_number: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required),
    fixed_asset_group: new FormControl('', Validators.required),
    location: new FormControl('', Validators.required),
    person_responsible: new FormControl('', Validators.required),
    purchase_value: new FormControl('', Validators.required),
    number_of_years_in_use: new FormControl('', Validators.required),
    order_date: new FormControl('', Validators.required),
    date_of_first_use: new FormControl('', Validators.required),
    date_of_last_use: new FormControl('', Validators.required)
  });

  hashValueGetter = function (params) {
    return ++params.node.rowIndex;
  };

  columnDefs = [
    {
      headerName: 'Sno', maxWidth: 100, valueGetter: this.hashValueGetter,
    },
    {
      headerName: 'Fixed Asset', field: 'fixed_asset', width: 200, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Asset Serial Number', field: 'asset_serial_number', width: 200, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Description', field: 'description', width: 200, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Fixed Asset Group', field: 'fixed_asset_droup', width: 200, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Location', field: 'location', width: 200, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Person Responsible', field: 'person_responsible', width: 200, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Purchase Value', field: 'purchase_value', width: 200, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Number Of Years In Use', field: 'number_of_years_in_use', width: 200, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Order Date', field: 'order_date', width: 200, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Date of First Use', field: 'date_of_first_use', width: 200, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Date of Last Use', field: 'date_of_last_use', width: 200, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Action',
      width: 90,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.onBtnClick.bind(this),
        // label: 'Edit',
        icon: 'fa fa-edit'
      }
    },
    {
      headerName: '',
      width: 110,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.deleteItem.bind(this),
        // label: 'Delete',
        icon: 'fa fa-trash'
      }
    },
  ];

  rowData = [
  ];

  gridOptions: GridOptions = {
    columnDefs: this.columnDefs,
    rowData: null,
    getRowStyle: this.getRowStyleScheduled
  };
  gridApi: any;
  gridColumnApi: any;
  rowClassRules: any;
  inValidRowNode: boolean;

  constructor(private modalService: NgbModal, private formBuilder: FormBuilder, private assetsService: AssetsService, private datePipe: DatePipe) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.isEdit = false;
    if (this.staticAlert) {
      setTimeout(() => this.staticAlert.close(), 20000);
    }
    this._success.subscribe(message => this.successMessage = message);
    this._success.pipe(debounceTime(5000)).subscribe(() => {
      if (this.selfClosingAlert) {
        this.selfClosingAlert.close();
      }
    });
    // this.getAllAssets();
    this.paginationPageSize = 10;
  }

  getRowStyleScheduled(params) {
    if (params.node.rowIndex % 2 == 0) {
      return {
        'background-color': 'rgba(0,0,0,.05)',
      }
    }
    return null;
  };


  get f() { return this.form.controls; }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onSubmit() {
    this.submitted = true;
    let close: any = document.querySelector('#closeForm');
    if (this.form.invalid) {
      return;
    }
    else {
      this.assets.fixed_asset = this.assets.fixed_asset.trim();
      this.assets.asset_serial_number = this.assets.asset_serial_number.trim();
      this.assets.description = this.assets.description.trim();
      this.assets.fixed_asset_group = this.assets.fixed_asset_group.trim();
      this.assets.location = this.assets.location.trim();
      if (!this.isEdit) {
        this.assetsService.addAssets(this.assets).subscribe((res) => {
          console.log(res);
          close.click();
          this.assetsId = 0;
          this.submitted = false;
          this._success.next(`Data Saved Successfully`);
          this.getAllAssets();
        });
      }
      else {
        this.assetsService.updateAssets(this.assets).subscribe((res: any) => {
          this.isEdit = false;
          if (res && res.rowsAffected) {
            this.submitted = false;
            close.click();
            this._success.next(`Data Updated Successfully`);
            this.getAllAssets();
          }
        });
      }
      this.assets = { fixed_asset: '', asset_serial_number: '', description:'', fixed_asset_group:'',location: '', person_responsible: 0, purchase_value: 0 , number_of_years_in_use: 0 ,order_date: '', date_of_first_use: '', date_of_last_use:'',  id: 0 };
    }
  }


  onBtnClick(row) {
    this.isEdit = true;
    this.assetsId = row.rowData.id;
    this.assetsService.findAssets(this.assetsId).subscribe((res: any) => {
      this.assets.id = this.assetsId;
      this.assets = res.recordset[0];

    })
    this.open(this.content);
  }

  deleteItem(row) {
    this.assetsId = row.rowData.id;
    this.itemToBeDeleted = row.rowData.title;
    this.open(this.confirmModel);
  }

  deleteClose() {

    let closeDel: any = document.querySelector('#closeDel');
    this.assetsService.deleteAssets(this.assetsId).subscribe((res) => {
      closeDel.click();
      this._success.next(`Deleted Successfully`);
      this.getAllAssets();
    })
  }

  getAllAssets() {
    this.assetsService.getAllAssets().subscribe((res: any) => {
      for (let i = 0; i < res.recordset.length; i++) {
        res.recordset[i].order_date = this.datePipe.transform(res.recordset[i].order_date, 'dd-MM-yyyy');
        res.recordset[i].date_of_first_use = this.datePipe.transform(res.recordset[i].date_of_first_use, 'dd-MM-yyyy');
        res.recordset[i].date_of_last_use = this.datePipe.transform(res.recordset[i].date_of_last_use, 'dd-MM-yyyy');
      }
      this.rowData = res.recordset;
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.assetsService.getAllAssets().subscribe((res: any) => {
      for (let i = 0; i < res.recordset.length; i++) {
        res.recordset[i].order_date = this.datePipe.transform(res.recordset[i].order_date, 'dd-MM-yyyy');
        res.recordset[i].date_of_first_use = this.datePipe.transform(res.recordset[i].date_of_first_use, 'dd-MM-yyyy');
        res.recordset[i].date_of_last_use = this.datePipe.transform(res.recordset[i].date_of_last_use, 'dd-MM-yyyy');
      }
      params.api.setRowData(res.recordset)
    })
  }

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchText);
  }
}

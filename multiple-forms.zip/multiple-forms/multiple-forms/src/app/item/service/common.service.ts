import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllItems() {
    return this.http.post(`${this.url}/getAllItems`, []);
  }

  findItem(id) {
    return this.http.post(`${this.url}/findItem`, { id: id });
  }

  addItem(item) {
    return this.http.post(`${this.url}/addItem`, item);
  }

  updateItem(item) {
    return this.http.post(`${this.url}/updateItem`, item);
  }

  deleteItem(id) {
    return this.http.post(`${this.url}/deleteItem`, { id: id });
  }

}

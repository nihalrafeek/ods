import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ChartOfAccountsService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllChartOfAccounts() {
    return this.http.post(`${this.url}/getAllChartOfAccounts`, []);
  }

  findChartOfAccount(id) {
    return this.http.post(`${this.url}/findChartOfAccount`, { id: id });
  }

  addChartOfAccount(item) {
    return this.http.post(`${this.url}/addChartOfAccount`, item);
  }

  updateChartOfAccount(item) {
    return this.http.post(`${this.url}/updateChartOfAccount`, item);
  }

  deleteChartOfAccount(id) {
    return this.http.post(`${this.url}/deleteChartOfAccount`, { id: id });
  }

}

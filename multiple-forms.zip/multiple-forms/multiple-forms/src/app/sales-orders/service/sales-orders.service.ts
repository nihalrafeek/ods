import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SalesOrdersService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllSalesOrders() {
    return this.http.post(`${this.url}/getAllSalesOrders`, []);
  }

  findSalesOrder(id) {
    return this.http.post(`${this.url}/findSalesOrder`, { id: id });
  }

  addSalesOrder(item) {
    return this.http.post(`${this.url}/addSalesOrder`, item);
  }

  updateSalesOrder(item) {
    return this.http.post(`${this.url}/updateSalesOrder`, item);
  }

  deleteSalesOrder(id) {
    return this.http.post(`${this.url}/deleteSalesOrder`, { id: id });
  }
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { ButtonRendererComponent } from './../renderer/button-renderer.component';
import { NgbModal, ModalDismissReasons, NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ItemDataService } from './service/item-data.service';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { GridOptions } from 'ag-grid-community';
import { CurrenciesService } from '../currencies/service/currencies.service';

@Component({
  selector: 'app-item-data',
  templateUrl: './item-data.component.html',
  styleUrls: ['./item-data.component.scss']
})
export class ItemDataComponent implements OnInit {

  closeResult = '';
  frameworkComponents: any;
  isEdit: boolean;
  staticAlertClosed = false;
  successMessage = '';
  itemGroupId: number;
  private _success = new Subject<string>();
  itemToBeDeleted;
  paginationPageSize;
  searchText;

  country_list: any = [{ id: 1, title: "India" }, { id: 2, title: "UK" }, { id: 3, title: "USA" }];
  state_list: any = [{ id: 1, title: "Tamil Nadu" }, { id: 2, title: "Delhi" }, { id: 3, title: "Mumbai" }];
  city_list: any = [{ id: 1, title: "Trichy" }, { id: 2, title: "Chennai" }, { id: 3, title: "Madurai" }];
  currency_list;

  @ViewChild('content', { static: false }) private content;
  @ViewChild('confirmModel', { static: false }) private confirmModel;
  @ViewChild('staticAlert', { static: false }) staticAlert: NgbAlert;
  @ViewChild('selfClosingAlert', { static: false }) selfClosingAlert: NgbAlert;


  item_data = { title: '', description: '', type: '', group: '', product_type: '', product_line: '', tax_code: '', inventory_unit: '', weight: '', signal_code: '', warehouse: '', re_order_point: 0, lot_control: '', safety_stock: 0, bom_unit: 0, routing_unit: 0, purchase_price: 0, purchase_price_unit: '', purchase_currency: '', buyer: 0, sales_price: 0, sales_price_unit: '', standard_cost_price: 0, material_costs: 0, operation_costs: 0, overhead_costs: 0, id: 0 };
  formModalReference;
  submitted = false;
  form = new FormGroup({
    title: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required),
    type: new FormControl('', Validators.required),
    group: new FormControl('', Validators.required),
    product_type: new FormControl('', Validators.required),
    product_line: new FormControl('', Validators.required),
    tax_code: new FormControl('', Validators.required),
    inventory_unit: new FormControl('', Validators.required),
    weight: new FormControl('', Validators.required),
    signal_code: new FormControl('', Validators.required),
    warehouse: new FormControl('', Validators.required),
    re_order_point: new FormControl('', Validators.required),
    lot_control: new FormControl('', Validators.required),
    safety_stock: new FormControl('', Validators.required),
    bom_unit: new FormControl('', Validators.required),
    routing_unit: new FormControl('', Validators.required),
    purchase_price: new FormControl('', Validators.required),
    purchase_price_unit: new FormControl('', Validators.required),
    purchase_currency: new FormControl('', Validators.required),
    buyer: new FormControl('', Validators.required),
    sales_price: new FormControl('', Validators.required),
    sales_price_unit: new FormControl('', Validators.required),
    standard_cost_price: new FormControl('', Validators.required),
    material_costs: new FormControl('', Validators.required),
    operation_costs: new FormControl('', Validators.required),
    overhead_costs: new FormControl('', Validators.required),
  });

  hashValueGetter = function (params) {
    return ++params.node.rowIndex;
  };

  columnDefs = [
    {
      headerName: 'Sno', field: '', maxWidth: 100, valueGetter: this.hashValueGetter,
    },
    {
      headerName: 'Item', field: 'title', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Description', field: 'description', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Item Type', field: 'type', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Item Group', field: 'group', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Product Type', field: 'product_type', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Product Line', field: 'product_line', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Tax code', field: 'tax_code', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Inventory Unit', field: 'inventory_unit', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Weight', field: 'weight', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Signal Code', field: 'signal_code', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Warehouse', field: 'warehouse', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Re Order Point', field: 're_order_point', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Lot Control', field: 'lot_control', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Safety Stock', field: 'safety_stock', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },

    {
      headerName: 'BOM Unit', field: 'bom_unit', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Routing Unit', field: 'routing_unit', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Purchase Price', field: 'purchase_price', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Purchase Price Unit', field: 'purchase_price_unit', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Purchase Currency', field: 'purchase_currency', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Buyer', field: 'buyer', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Sales Price', field: 'sales_price', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Sales Price Unit', field: 'sales_price_unit', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Standard Cost Price', field: 'standard_cost_price', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Material Costs', field: 'material_costs', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Operation Costs', field: 'operation_costs', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Overhead Costs', field: 'overhead_costs', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Action',
      width: 90,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.onBtnClick.bind(this),
        // label: 'Edit',
        icon: 'fa fa-edit'
      }
    },
    {
      headerName: '',
      width: 110,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.deleteItem.bind(this),
        // label: 'Delete',
        icon: 'fa fa-trash'
      }
    },
  ];

  rowData = [
  ];

  gridOptions: GridOptions = {
    columnDefs: this.columnDefs,
    rowData: null,
    getRowStyle: this.getRowStyleScheduled
  };
  gridApi: any;
  gridColumnApi: any;
  rowClassRules: any;
  inValidRowNode: boolean;

  constructor(private modalService: NgbModal, private currencyService: CurrenciesService, private itemDataService: ItemDataService) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.isEdit = false;
    if (this.staticAlert) {
      setTimeout(() => this.staticAlert.close(), 20000);
    }
    this._success.subscribe(message => this.successMessage = message);
    this._success.pipe(debounceTime(5000)).subscribe(() => {
      if (this.selfClosingAlert) {
        this.selfClosingAlert.close();
      }
    });
    this.getCurrencyList();
    this.paginationPageSize = 10;
  }

  getCurrencyList() {
    this.currencyService.getAllCurrency().subscribe((res: any) => {
      this.currency_list = res.recordset;
    });
  }

  getRowStyleScheduled(params) {
    if (params.node.rowIndex % 2 == 0) {
      return {
        'background-color': 'rgba(0,0,0,.05)',
      }
    }
    return null;
  };


  get f() { return this.form.controls; }

  open(content) {
    this.modalService.open(content, {size: 'lg', ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onSubmit() {
    this.submitted = true;
    let close: any = document.querySelector('#closeForm');
    if (this.form.invalid) {
      return;
    }
    else {
      this.item_data.title = this.item_data.title.trim();
      this.item_data.description = this.item_data.description.trim();
      this.item_data.type = this.item_data.type.trim();
      this.item_data.group = this.item_data.group.trim();
      this.item_data.product_type = this.item_data.product_type.trim();
      this.item_data.product_line = this.item_data.product_line.trim();
      this.item_data.tax_code = this.item_data.tax_code.trim();
      this.item_data.inventory_unit = this.item_data.inventory_unit.trim();
      this.item_data.signal_code = this.item_data.signal_code.trim();
      this.item_data.warehouse = this.item_data.warehouse.trim();
      this.item_data.purchase_price_unit = this.item_data.purchase_price_unit.trim();
      this.item_data.purchase_currency = this.item_data.purchase_currency.trim();
      this.item_data.sales_price_unit = this.item_data.sales_price_unit.trim();
      if (!this.isEdit) {
        this.itemDataService.addItemData(this.item_data).subscribe((res) => {
          console.log(res);
          close.click();
          this.itemGroupId = 0;
          this.submitted = false;
          this._success.next(`Data Saved Successfully`);
          this.getAllItemData();
        });
      }
      else {
        this.itemDataService.updateItemData(this.item_data).subscribe((res: any) => {
          this.isEdit = false;
          if (res && res.rowsAffected) {
            this.submitted = false;
            close.click();
            this._success.next(`Data Updated Successfully`);
            this.getAllItemData();
          }
        });
      }
      this.item_data = { title: '', description: '', type: '', group: '', product_type: '', product_line: '', tax_code: '', inventory_unit: '', weight: '', signal_code: '', warehouse: '', re_order_point: 0, lot_control: '', safety_stock: 0, bom_unit: 0, routing_unit: 0, purchase_price: 0, purchase_price_unit: '', purchase_currency: '', buyer: 0, sales_price: 0, sales_price_unit: '', standard_cost_price: 0, material_costs: 0, operation_costs: 0, overhead_costs: 0, id: 0 };

    }
  }


  onBtnClick(row) {
    this.isEdit = true;
    this.itemGroupId = row.rowData.id;
    this.itemDataService.findItemData(this.itemGroupId).subscribe((res: any) => {
      this.item_data.id = this.itemGroupId;
      this.item_data = res.recordset[0];
    })
    this.open(this.content);
  }

  deleteItem(row) {
    this.itemGroupId = row.rowData.id;
    this.itemToBeDeleted = row.rowData.title;
    this.open(this.confirmModel);
  }

  deleteClose() {

    let closeDel: any = document.querySelector('#closeDel');
    this.itemDataService.deleteItemData(this.itemGroupId).subscribe((res) => {
      closeDel.click();
      this._success.next(`Deleted Successfully`);
      this.getAllItemData();
    })
  }

  getAllItemData() {
    this.itemDataService.getAllItemData().subscribe((res: any) => {
      this.rowData = res.recordset;
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.itemDataService.getAllItemData().subscribe((res: any) => {
      params.api.setRowData(res.recordset)
    })
  }

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchText);
  }

}

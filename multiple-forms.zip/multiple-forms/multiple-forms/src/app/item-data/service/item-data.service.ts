import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ItemDataService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllItemData() {
    return this.http.post(`${this.url}/getAllItemData`, []);
  }

  findItemData(id) {
    return this.http.post(`${this.url}/findItemData`, { id: id });
  }

  addItemData(item) {
    return this.http.post(`${this.url}/addItemData`, item);
  }

  updateItemData(item) {
    return this.http.post(`${this.url}/updateItemData`, item);
  }

  deleteItemData(id) {
    return this.http.post(`${this.url}/deleteItemData`, { id: id });
  }
}

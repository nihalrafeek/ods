import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import '@angular/compiler';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutModule } from './layout/layout.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ItemComponent } from './item/item.component';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
import { ProductTypeComponent } from './product-type/product-type.component';
import { ProductLineComponent } from './product-line/product-line.component';
import { WarehouseComponent } from './warehouse/warehouse.component';
import { TermsOfDeliveryComponent } from './terms-of-delivery/terms-of-delivery.component';
import { TermsOfPaymentComponent } from './terms-of-payment/terms-of-payment.component';
import { CurrenciesComponent } from './currencies/currencies.component';
import { ReasonCodesComponent } from './reason-codes/reason-codes.component';
import { LocationComponent } from './location/location.component';
import { UnitsComponent } from './units/units.component';
import { ConversionFactorComponent } from './conversion-factor/conversion-factor.component';
import { FirstFreeNumberComponent } from './first-free-number/first-free-number.component';
import { ItemCodeBySystemComponent } from './item-code-by-system/item-code-by-system.component';
import { LineOfBusinessComponent } from './line-of-business/line-of-business.component';
import { EmployeeComponent } from './employee/employee.component';
import { CustomersComponent } from './customers/customers.component';
import { SuppliersComponent } from './suppliers/suppliers.component';
import { ItemDataComponent } from './item-data/item-data.component';
import { PeriodsComponent } from './periods/periods.component';
import { CurrencyRatesComponent } from './currency-rates/currency-rates.component';
import { TransactionTypesComponent } from './transaction-types/transaction-types.component';
import { ChartOfAccountsComponent } from './chart-of-accounts/chart-of-accounts.component';
import { DimensionsComponent } from './dimensions/dimensions.component';
import { AssetGroupsComponent } from './asset-groups/asset-groups.component';
import { AssetLocationsComponent } from './asset-locations/asset-locations.component';
import { DatePipe } from '@angular/common';
import { AssetsComponent } from './assets/assets.component';
import { DepreciationComponent } from './depreciation/depreciation.component';
import { SalesOrdersComponent } from './sales-orders/sales-orders.component';
import { PurchaseOrdersComponent } from './purchase-orders/purchase-orders.component';
import { SalesContractsComponent } from './sales-contracts/sales-contracts.component';

@NgModule({
  declarations: [
    AppComponent,
    ItemComponent,
    ProductTypeComponent,
    ProductLineComponent,
    WarehouseComponent,
    TermsOfDeliveryComponent,
    TermsOfPaymentComponent,
    CurrenciesComponent,
    ReasonCodesComponent,
    LocationComponent,
    UnitsComponent,
    ConversionFactorComponent,
    FirstFreeNumberComponent,
    ItemCodeBySystemComponent,
    LineOfBusinessComponent,
    EmployeeComponent,
    CustomersComponent,
    SuppliersComponent,
    ItemDataComponent,
    PeriodsComponent,
    CurrencyRatesComponent,
    TransactionTypesComponent,
    ChartOfAccountsComponent,
    DimensionsComponent,
    AssetGroupsComponent,
    AssetLocationsComponent,
    AssetsComponent,
    DepreciationComponent,
    SalesOrdersComponent,
    PurchaseOrdersComponent,
    SalesContractsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LayoutModule,
    AgGridModule.withComponents([]),
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TermsOfDeliveryComponent } from './terms-of-delivery.component';

describe('TermsOfDeliveryComponent', () => {
  let component: TermsOfDeliveryComponent;
  let fixture: ComponentFixture<TermsOfDeliveryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TermsOfDeliveryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TermsOfDeliveryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { TestBed } from '@angular/core/testing';

import { TermsOfDeliveryService } from './terms-of-delivery.service';

describe('TermsOfDeliveryService', () => {
  let service: TermsOfDeliveryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TermsOfDeliveryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

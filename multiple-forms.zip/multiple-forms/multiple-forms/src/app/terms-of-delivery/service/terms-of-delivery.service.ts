import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TermsOfDeliveryService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllDeliveryTerm() {
    return this.http.post(`${this.url}/getAllDeliveryTerms`, []);
  }

  findDeliveryTerm(id) {
    return this.http.post(`${this.url}/findDeliveryTerm`, { id: id });
  }

  addDeliveryTerm(item) {
    return this.http.post(`${this.url}/addDeliveryTerm`, item);
  }

  updateDeliveryTerm(item) {
    return this.http.post(`${this.url}/updateDeliveryTerm`, item);
  }

  deleteDeliveryTerm(id) {
    return this.http.post(`${this.url}/deleteDeliveryTerm`, { id: id });
  }
}

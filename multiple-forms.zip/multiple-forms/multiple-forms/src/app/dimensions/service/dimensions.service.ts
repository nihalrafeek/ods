import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DimensionsService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllDimensions() {
    return this.http.post(`${this.url}/getAllDimensions`, []);
  }

  findDimension(id) {
    return this.http.post(`${this.url}/findDimension`, { id: id });
  }

  addDimension(item) {
    return this.http.post(`${this.url}/addDimension`, item);
  }

  updateDimension(item) {
    return this.http.post(`${this.url}/updateDimension`, item);
  }

  deleteDimension(id) {
    return this.http.post(`${this.url}/deleteDimension`, { id: id });
  }

}

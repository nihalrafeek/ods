import { TestBed } from '@angular/core/testing';

import { LineOfBusinessService } from './line-of-business.service';

describe('LineOfBusinessService', () => {
  let service: LineOfBusinessService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LineOfBusinessService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LineOfBusinessService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllLineOfBusiness() {
    return this.http.post(`${this.url}/getAllLineOfBusiness`, []);
  }

  findLineOfBusiness(id) {
    return this.http.post(`${this.url}/findLineOfBusiness`, { id: id });
  }

  addLineOfBusiness(item) {
    return this.http.post(`${this.url}/addLineOfBusiness`, item);
  }

  updateLineOfBusiness(item) {
    return this.http.post(`${this.url}/updateLineOfBusiness`, item);
  }

  deleteLineOfBusiness(id) {
    return this.http.post(`${this.url}/deleteLineOfBusiness`, { id: id });
  }

}

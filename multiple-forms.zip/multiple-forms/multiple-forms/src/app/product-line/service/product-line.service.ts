import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProductLineService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllProductLine() {
    return this.http.post(`${this.url}/getAllProductLine`, []);
  }

  findProductLine(id) {
    return this.http.post(`${this.url}/findProductLine`, { id: id });
  }

  addProductLine(item) {
    return this.http.post(`${this.url}/addProductLine`, item);
  }

  updateProductLine(item) {
    return this.http.post(`${this.url}/updateProductLine`, item);
  }

  deleteProductLine(id) {
    return this.http.post(`${this.url}/deleteProductLine`, { id: id });
  }

}

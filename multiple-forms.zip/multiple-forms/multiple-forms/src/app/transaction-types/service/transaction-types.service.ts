import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TransactionTypesService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllTransactionTypes() {
    return this.http.post(`${this.url}/getAllTransactionTypes`, []);
  }

  findTransactionType(id) {
    return this.http.post(`${this.url}/findTransactionType`, { id: id });
  }

  addTransactionType(item) {
    return this.http.post(`${this.url}/addTransactionType`, item);
  }

  updateTransactionType(item) {
    return this.http.post(`${this.url}/updateTransactionType`, item);
  }

  deleteTransactionType(id) {
    return this.http.post(`${this.url}/deleteTransactionType`, { id: id });
  }

}

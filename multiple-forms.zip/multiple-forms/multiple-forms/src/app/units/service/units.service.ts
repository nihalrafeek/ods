import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UnitsService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllUnits() {
    return this.http.post(`${this.url}/getAllUnits`, []);
  }

  findUnit(id) {
    return this.http.post(`${this.url}/findUnit`, { id: id });
  }

  addUnit(item) {
    return this.http.post(`${this.url}/addUnit`, item);
  }

  updateUnit(item) {
    return this.http.post(`${this.url}/updateUnit`, item);
  }

  deleteUnit(id) {
    return this.http.post(`${this.url}/deleteUnit`, { id: id });
  }

}

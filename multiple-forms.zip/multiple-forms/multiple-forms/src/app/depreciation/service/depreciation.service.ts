import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DepreciationService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllDepreciations() {
    return this.http.post(`${this.url}/getAllDepreciations`, []);
  }

  findDepreciation(id) {
    return this.http.post(`${this.url}/findDepreciation`, { id: id });
  }

  addDepreciation(item) {
    return this.http.post(`${this.url}/addDepreciation`, item);
  }

  updateDepreciation(item) {
    return this.http.post(`${this.url}/updateDepreciation`, item);
  }

  deleteDepreciation(id) {
    return this.http.post(`${this.url}/deleteDepreciation`, { id: id });
  }

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssetGroupsComponent } from './asset-groups/asset-groups.component';
import { AssetLocationsComponent } from './asset-locations/asset-locations.component';
import { AssetsComponent } from './assets/assets.component';
import { ChartOfAccountsComponent } from './chart-of-accounts/chart-of-accounts.component';
import { ConversionFactorComponent } from './conversion-factor/conversion-factor.component';
import { CurrenciesComponent } from './currencies/currencies.component';
import { CurrencyRatesComponent } from './currency-rates/currency-rates.component';
import { CustomersComponent } from './customers/customers.component';
import { DepreciationComponent } from './depreciation/depreciation.component';
import { DimensionsComponent } from './dimensions/dimensions.component';
import { EmployeeComponent } from './employee/employee.component';
import { FirstFreeNumberComponent } from './first-free-number/first-free-number.component';
import { ItemCodeBySystemComponent } from './item-code-by-system/item-code-by-system.component';
import { ItemDataComponent } from './item-data/item-data.component';
import { ItemComponent } from './item/item.component';
import { LineOfBusinessComponent } from './line-of-business/line-of-business.component';
import { LocationComponent } from './location/location.component';
import { PeriodsComponent } from './periods/periods.component';
import { ProductLineComponent } from './product-line/product-line.component';
import { ProductTypeComponent } from './product-type/product-type.component';
import { PurchaseOrdersComponent } from './purchase-orders/purchase-orders.component';
import { ReasonCodesComponent } from './reason-codes/reason-codes.component';
import { SalesContractsComponent } from './sales-contracts/sales-contracts.component';
import { SalesOrdersComponent } from './sales-orders/sales-orders.component';
import { SuppliersComponent } from './suppliers/suppliers.component';
import { TermsOfDeliveryComponent } from './terms-of-delivery/terms-of-delivery.component';
import { TermsOfPaymentComponent } from './terms-of-payment/terms-of-payment.component';
import { TransactionTypesComponent } from './transaction-types/transaction-types.component';
import { UnitsComponent } from './units/units.component';
import { WarehouseComponent } from './warehouse/warehouse.component';

const routes: Routes = [
  { path: '', component: ItemComponent },
  { path: 'item-group', component: ItemComponent },
  { path: 'product-line', component: ProductLineComponent },
  { path: 'product-type', component: ProductTypeComponent },
  { path: 'warehouse', component: WarehouseComponent },
  { path: 'terms-of-delivery', component: TermsOfDeliveryComponent },
  { path: 'terms-of-payment', component: TermsOfPaymentComponent },
  { path: 'currencies', component: CurrenciesComponent },
  { path: 'reason-codes', component: ReasonCodesComponent },
  { path: 'location', component: LocationComponent },
  { path: 'units', component: UnitsComponent },
  { path: 'conversion-factor', component: ConversionFactorComponent },
  { path: 'first-free-number', component: FirstFreeNumberComponent },
  { path: 'item-code-system', component: ItemCodeBySystemComponent },
  { path: 'line-of-business', component: LineOfBusinessComponent },
  { path: 'employee', component: EmployeeComponent },
  { path: 'customers', component: CustomersComponent },
  { path: 'suppliers', component: SuppliersComponent },
  { path: 'asset-locations', component: AssetLocationsComponent },
  { path: 'asset-groups', component: AssetGroupsComponent },
  { path: 'dimension', component: DimensionsComponent },
  { path: 'chart-of-accounts', component: ChartOfAccountsComponent },
  { path: 'transaction-type', component: TransactionTypesComponent },
  { path: 'currency-rates', component: CurrencyRatesComponent },
  { path: 'periods', component: PeriodsComponent },
  { path: 'item-data', component: ItemDataComponent },
  { path: 'assets', component: AssetsComponent },
  { path: 'depreciation', component: DepreciationComponent },
  { path: 'sales-orders', component: SalesOrdersComponent },
  { path: 'purchase-orders', component: PurchaseOrdersComponent },
  { path: 'sales-contracts', component: SalesContractsComponent },
  // {
  //   path: '',
  //   children: [
  //     {
  //       path: '',
  //       loadChildren: './layout/layout.module#LayoutModule'
  //     }],
  // },
  // {
  //   path: 'form',
  //   children: [
  //     {
  //       path: '',
  //       loadChildren: './layout/layout.module#LayoutModule'
  //     }],
  // },
  // {
  //   path: '',
  //   children: [
  //     {
  //       path: '',
  //       loadChildren: './form/form.module#FormModule'
  //     }],
  // },
  // {
  //   path: 'form',
  //   children: [
  //     {
  //       path: '',
  //       loadChildren: './master/master.module#MasterModule'
  //     }],
  // },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProductTypeService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllProductType() {
    return this.http.post(`${this.url}/getAllProductType`, []);
  }

  findProductType(id) {
    return this.http.post(`${this.url}/findProductType`, { id: id });
  }

  addProductType(item) {
    return this.http.post(`${this.url}/addProductType`, item);
  }

  updateProductType(item) {
    return this.http.post(`${this.url}/updateProductType`, item);
  }

  deleteProductType(id) {
    return this.http.post(`${this.url}/deleteProductType`, { id: id });
  }

}

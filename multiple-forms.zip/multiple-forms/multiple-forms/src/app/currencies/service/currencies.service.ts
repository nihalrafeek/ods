import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class CurrenciesService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllCurrency() {
    return this.http.post(`${this.url}/getAllCurrency`, []);
  }

  findCurrency(id) {
    return this.http.post(`${this.url}/findCurrency`, { id: id });
  }

  addCurrency(item) {
    return this.http.post(`${this.url}/addCurrency`, item);
  }

  updateCurrency(item) {
    return this.http.post(`${this.url}/updateCurrency`, item);
  }

  deleteCurrency(id) {
    return this.http.post(`${this.url}/deleteCurrency`, { id: id });
  }

}

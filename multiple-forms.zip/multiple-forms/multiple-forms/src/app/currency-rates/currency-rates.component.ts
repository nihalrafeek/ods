import { Component, OnInit, ViewChild } from '@angular/core';
import { ButtonRendererComponent } from './../renderer/button-renderer.component';
import { NgbModal, ModalDismissReasons, NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CurrencyRatesService } from './service/currency-rates.service';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { GridOptions } from 'ag-grid-community';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-currency-rates',
  templateUrl: './currency-rates.component.html',
  styleUrls: ['./currency-rates.component.scss']
})
export class CurrencyRatesComponent implements OnInit {

  closeResult = '';
  frameworkComponents: any;
  isEdit: boolean;
  staticAlertClosed = false;
  successMessage = '';
  currencyId: number;
  private _success = new Subject<string>();
  itemToBeDeleted;
  paginationPageSize;
  searchText;

  @ViewChild('content', { static: false }) private content;
  @ViewChild('confirmModel', { static: false }) private confirmModel;
  @ViewChild('staticAlert', { static: false }) staticAlert: NgbAlert;
  @ViewChild('selfClosingAlert', { static: false }) selfClosingAlert: NgbAlert;


  currencies_rates = { title: '', effective_date: '', purchase_rate: 0, sales_rate: 0,  id: 0 };
  formModalReference;
  submitted = false;
  form = new FormGroup({
    title: new FormControl('', Validators.required),
    effective_date: new FormControl('', Validators.required),
    purchase_rate: new FormControl('', Validators.required),
    sales_rate: new FormControl('', Validators.required)
  });

  hashValueGetter = function (params) {
    return ++params.node.rowIndex;
  };

  columnDefs = [
    {
      headerName: 'Sno', field: 'title', maxWidth: 100, valueGetter: this.hashValueGetter,
    },
    {
      headerName: 'Currency', field: 'title', width: 200, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Effective Date', field: 'effective_date', width: 200, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Purchase Rate', field: 'purchase_rate', width: 200, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Sales Rate', field: 'sales_rate', width: 200, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Action',
      width: 90,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.onBtnClick.bind(this),
        // label: 'Edit',
        icon: 'fa fa-edit'
      }
    },
    {
      headerName: '',
      width: 110,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.deleteItem.bind(this),
        // label: 'Delete',
        icon: 'fa fa-trash'
      }
    },
  ];

  rowData = [
  ];

  gridOptions: GridOptions = {
    columnDefs: this.columnDefs,
    rowData: null,
    getRowStyle: this.getRowStyleScheduled
  };
  gridApi: any;
  gridColumnApi: any;
  rowClassRules: any;
  inValidRowNode: boolean;

  constructor(private modalService: NgbModal, private datePipe: DatePipe, private currencyRatesService: CurrencyRatesService) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.isEdit = false;
    if (this.staticAlert) {
      setTimeout(() => this.staticAlert.close(), 20000);
    }
    this._success.subscribe(message => this.successMessage = message);
    this._success.pipe(debounceTime(5000)).subscribe(() => {
      if (this.selfClosingAlert) {
        this.selfClosingAlert.close();
      }
    });
    // this.getAllCurrencyRates();
    this.paginationPageSize = 10;
    // this.currencies_rates.effective_date = this.datePipe.transform(new Date(), 'dd-MM-yy');
  }

  getRowStyleScheduled(params) {
    if (params.node.rowIndex % 2 == 0) {
      return {
        'background-color': 'rgba(0,0,0,.05)',
      }
    }
    return null;
  };

  dateFormatter(params) {
    // this.date = this.datePipe.transform(new Date(), 'dd-MM-yy');
  }

  get f() { return this.form.controls; }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onSubmit() {
    this.submitted = true;
    let close: any = document.querySelector('#closeForm');
    if (this.form.invalid) {
      return;
    }
    else {
      this.currencies_rates.title = this.currencies_rates.title.trim();
      if (!this.isEdit) {
        this.currencyRatesService.addCurrencyRates(this.currencies_rates).subscribe((res) => {
          console.log(res);
          close.click();
          this.currencyId = 0;
          this.submitted = false;
          this._success.next(`Data Saved Successfully`);
          this.getAllCurrencyRates();
        });
      }
      else {
        this.currencyRatesService.updateCurrencyRates(this.currencies_rates).subscribe((res: any) => {
          this.isEdit = false;
          if (res && res.rowsAffected) {
            this.submitted = false;
            close.click();
            this._success.next(`Data Updated Successfully`);
            this.getAllCurrencyRates();
          }
        });
      }
      this.currencies_rates = { title: '', effective_date: '', purchase_rate: 0, sales_rate: 0,  id: 0 };
    }
  }


  onBtnClick(row) {
    this.isEdit = true;
    this.currencyId = row.rowData.id;
    this.currencyRatesService.findCurrencyRates(this.currencyId).subscribe((res: any) => {
      this.currencies_rates.id = this.currencyId;
      this.currencies_rates = res.recordset[0];

    })
    this.open(this.content);
  }

  deleteItem(row) {
    this.currencyId = row.rowData.id;
    this.itemToBeDeleted = row.rowData.title;
    this.open(this.confirmModel);
  }

  deleteClose() {

    let closeDel: any = document.querySelector('#closeDel');
    this.currencyRatesService.deleteCurrencyRates(this.currencyId).subscribe((res) => {
      closeDel.click();
      this._success.next(`Deleted Successfully`);
      this.getAllCurrencyRates();
    })
  }

  getAllCurrencyRates() {
    this.currencyRatesService.getAllCurrencyRates().subscribe((res: any) => {
      this.rowData = res.recordset;
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.currencyRatesService.getAllCurrencyRates().subscribe((res: any) => {
      params.api.setRowData(res.recordset)
    })
  }

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchText);
  }


}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CurrencyRatesService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllCurrencyRates() {
    return this.http.post(`${this.url}/getAllCurrencyRates`, []);
  }

  findCurrencyRates(id) {
    return this.http.post(`${this.url}/findCurrencyRates`, { id: id });
  }

  addCurrencyRates(item) {
    return this.http.post(`${this.url}/addCurrencyRates`, item);
  }

  updateCurrencyRates(item) {
    return this.http.post(`${this.url}/updateCurrencyRates`, item);
  }

  deleteCurrencyRates(id) {
    return this.http.post(`${this.url}/deleteCurrencyRates`, { id: id });
  }

}

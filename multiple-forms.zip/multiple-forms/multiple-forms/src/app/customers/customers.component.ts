import { Component, OnInit, ViewChild } from '@angular/core';
import { ButtonRendererComponent } from './../renderer/button-renderer.component';
import { NgbModal, ModalDismissReasons, NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CustomersService } from './service/customers.service';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { GridOptions } from 'ag-grid-community';
import { CurrenciesService } from '../currencies/service/currencies.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss']
})
export class CustomersComponent implements OnInit {

  closeResult = '';
  frameworkComponents: any;
  isEdit: boolean;
  staticAlertClosed = false;
  successMessage = '';
  itemGroupId: number;
  private _success = new Subject<string>();
  itemToBeDeleted;
  paginationPageSize;
  searchText;

  country_list: any = [{ id: 1, title: "India" }, { id: 2, title: "UK" }, { id: 3, title: "USA" }];
  state_list: any = [{ id: 1, title: "Tamil Nadu" }, { id: 2, title: "Delhi" }, { id: 3, title: "Mumbai" }];
  city_list: any = [{ id: 1, title: "Trichy" }, { id: 2, title: "Chennai" }, { id: 3, title: "Madurai" }];
  currency_list;

  @ViewChild('content', { static: false }) private content;
  @ViewChild('confirmModel', { static: false }) private confirmModel;
  @ViewChild('staticAlert', { static: false }) staticAlert: NgbAlert;
  @ViewChild('selfClosingAlert', { static: false }) selfClosingAlert: NgbAlert;


  customer = { code: '', status: '', name: '', arabic_name: '', address: '', phone: 0, country_id: '', state_id: '', city_id: '', currency_id: '', sales_rep_id: '', customer_related_party: '', credit_limit: 0, vat_number: '', id: 0 };
  formModalReference;
  submitted = false;
  form = new FormGroup({
    code: new FormControl('', Validators.required),
    status: new FormControl('', Validators.required),
    name: new FormControl('', Validators.required),
    arabic_name: new FormControl('', Validators.required),
    address: new FormControl('', Validators.required),
    phone: new FormControl('', Validators.required),
    country_id: new FormControl('', Validators.required),
    state_id: new FormControl('', Validators.required),
    city_id: new FormControl('', Validators.required),
    currency_id: new FormControl('', Validators.required),
    sales_rep_id: new FormControl('', Validators.required),
    customer_related_party: new FormControl('', Validators.required),
    credit_limit: new FormControl('', Validators.required),
    vat_number: new FormControl('', Validators.required)
  });

  hashValueGetter = function (params) {
    return ++params.node.rowIndex;
  };

  columnDefs = [
    {
      headerName: 'Sno', field: '', maxWidth: 100, valueGetter: this.hashValueGetter,
    },
    {
      headerName: 'Customer Code', field: 'code', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Customer Status', field: 'status', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Name', field: 'name', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Arabic Name', field: 'arabic_name', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Address', field: 'address', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Phone', field: 'phone', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Country', field: 'country_id', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'State', field: 'state_id', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'City', field: 'city_id', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Currency', field: 'currency_id', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Sales Rep', field: 'sales_rep_id', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Customer Related Party', field: 'customer_related_party', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Credit Limt', field: 'credit_limit', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Vat Number', field: 'vat_number', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Action',
      width: 90,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.onBtnClick.bind(this),
        // label: 'Edit',
        icon: 'fa fa-edit'
      }
    },
    {
      headerName: '',
      width: 110,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.deleteItem.bind(this),
        // label: 'Delete',
        icon: 'fa fa-trash'
      }
    },
  ];

  rowData = [
  ];

  gridOptions: GridOptions = {
    columnDefs: this.columnDefs,
    rowData: null,
    getRowStyle: this.getRowStyleScheduled
  };
  gridApi: any;
  gridColumnApi: any;
  rowClassRules: any;
  inValidRowNode: boolean;

  constructor(private modalService: NgbModal, private currencyService: CurrenciesService, private customersService: CustomersService) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.isEdit = false;
    if (this.staticAlert) {
      setTimeout(() => this.staticAlert.close(), 20000);
    }
    this._success.subscribe(message => this.successMessage = message);
    this._success.pipe(debounceTime(5000)).subscribe(() => {
      if (this.selfClosingAlert) {
        this.selfClosingAlert.close();
      }
    });
    this.getCurrencyList();
    this.paginationPageSize = 10;
  }

  getCurrencyList() {
    this.currencyService.getAllCurrency().subscribe((res: any) => {
      this.currency_list = res.recordset;
    });
  }

  getRowStyleScheduled(params) {
    if (params.node.rowIndex % 2 == 0) {
      return {
        'background-color': 'rgba(0,0,0,.05)',
      }
    }
    return null;
  };


  get f() { return this.form.controls; }

  open(content) {
    this.modalService.open(content, {size: 'lg', ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onSubmit() {
    this.submitted = true;
    let close: any = document.querySelector('#closeForm');
    if (this.form.invalid) {
      return;
    }
    else {
      this.customer.code = this.customer.code.trim();
      this.customer.name = this.customer.name.trim();
      this.customer.arabic_name = this.customer.arabic_name.trim();
      this.customer.address = this.customer.address.trim();
      this.customer.vat_number = this.customer.vat_number.trim();
      if (!this.isEdit) {
        this.customersService.addCustomers(this.customer).subscribe((res) => {
          console.log(res);
          close.click();
          this.itemGroupId = 0;
          this.submitted = false;
          this._success.next(`Data Saved Successfully`);
          this.getAllCustomers();
        });
      }
      else {
        this.customersService.updateCustomers(this.customer).subscribe((res: any) => {
          this.isEdit = false;
          if (res && res.rowsAffected) {
            this.submitted = false;
            close.click();
            this._success.next(`Data Updated Successfully`);
            this.getAllCustomers();
          }
        });
      }
      this.customer = { code: '', status: '', name: '', arabic_name: '', address: '', phone: 0, country_id: '', state_id: '', city_id: '', currency_id: '', sales_rep_id: '', customer_related_party: '', credit_limit: 0, vat_number: '', id: 0 };

    }
  }


  onBtnClick(row) {
    this.isEdit = true;
    this.itemGroupId = row.rowData.id;
    this.customersService.findCustomers(this.itemGroupId).subscribe((res: any) => {
      this.customer.id = this.itemGroupId;
      this.customer = res.recordset[0];
    })
    this.open(this.content);
  }

  deleteItem(row) {
    this.itemGroupId = row.rowData.id;
    this.itemToBeDeleted = row.rowData.title;
    this.open(this.confirmModel);
  }

  deleteClose() {

    let closeDel: any = document.querySelector('#closeDel');
    this.customersService.deleteCustomers(this.itemGroupId).subscribe((res) => {
      closeDel.click();
      this._success.next(`Deleted Successfully`);
      this.getAllCustomers();
    })
  }

  getAllCustomers() {
    this.customersService.getAllCustomers().subscribe((res: any) => {
      this.rowData = res.recordset;
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.customersService.getAllCustomers().subscribe((res: any) => {
      params.api.setRowData(res.recordset)
    })
  }

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchText);
  }


}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CustomersService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllCustomers() {
    return this.http.post(`${this.url}/getAllCustomers`, []);
  }

  findCustomers(id) {
    return this.http.post(`${this.url}/findCustomer`, { id: id });
  }

  addCustomers(item) {
    return this.http.post(`${this.url}/addCustomer`, item);
  }

  updateCustomers(item) {
    return this.http.post(`${this.url}/updateCustomer`, item);
  }

  deleteCustomers(id) {
    return this.http.post(`${this.url}/deleteCustomer`, { id: id });
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ItemCodeBySystemService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllItemCodeBySystem() {
    return this.http.post(`${this.url}/getAllItemCodeBySystem`, []);
  }

  findItemCodeBySystem(id) {
    return this.http.post(`${this.url}/findItemCodeBySystem`, { id: id });
  }

  addItemCodeBySystem(item) {
    return this.http.post(`${this.url}/addItemCodeBySystem`, item);
  }

  updateItemCodeBySystem(item) {
    return this.http.post(`${this.url}/updateItemCodeBySystem`, item);
  }

  deleteItemCodeBySystem(id) {
    return this.http.post(`${this.url}/deleteItemCodeBySystem`, { id: id });
  }

}

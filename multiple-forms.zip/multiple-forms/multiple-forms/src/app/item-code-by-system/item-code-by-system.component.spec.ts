import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemCodeBySystemComponent } from './item-code-by-system.component';

describe('ItemCodeBySystemComponent', () => {
  let component: ItemCodeBySystemComponent;
  let fixture: ComponentFixture<ItemCodeBySystemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemCodeBySystemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemCodeBySystemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

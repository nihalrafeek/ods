import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReasonCodesService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllReasonCodes() {
    return this.http.post(`${this.url}/getAllReasonCodes`, []);
  }

  findReasonCodes(id) {
    return this.http.post(`${this.url}/findReasonCode`, { id: id });
  }

  addReasonCodes(item) {
    return this.http.post(`${this.url}/addReasonCode`, item);
  }

  updateReasonCodes(item) {
    return this.http.post(`${this.url}/updateReasonCode`, item);
  }

  deleteReasonCodes(id) {
    return this.http.post(`${this.url}/deleteReasonCode`, { id: id });
  }

}

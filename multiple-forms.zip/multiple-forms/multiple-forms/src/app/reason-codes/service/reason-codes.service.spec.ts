import { TestBed } from '@angular/core/testing';

import { ReasonCodesService } from './reason-codes.service';

describe('ReasonCodesService', () => {
  let service: ReasonCodesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReasonCodesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

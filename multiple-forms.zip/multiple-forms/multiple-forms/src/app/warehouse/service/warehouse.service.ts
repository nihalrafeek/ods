import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class WarehouseService {

  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllWarehouse() {
    return this.http.post(`${this.url}/getAllWarehouse`, []);
  }

  findWarehouse(id) {
    return this.http.post(`${this.url}/findWarehouse`, { id: id });
  }

  addWarehouse(item) {
    return this.http.post(`${this.url}/addWarehouse`, item);
  }

  updateWarehouse(item) {
    return this.http.post(`${this.url}/updateWarehouse`, item);
  }

  deleteWarehouse(id) {
    return this.http.post(`${this.url}/deleteWarehouse`, { id: id });
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PurchaseOrdersService {
  url;

  constructor(public http: HttpClient) { 
    this.url = environment.API_URL;
  }

  getAllPurchaseOrders() {
    return this.http.post(`${this.url}/getAllPurchaseOrders`, []);
  }

  findPurchaseOrder(id) {
    return this.http.post(`${this.url}/findPurchaseOrder`, { id: id });
  }

  addPurchaseOrder(item) {
    return this.http.post(`${this.url}/addPurchaseOrder`, item);
  }

  updatePurchaseOrder(item) {
    return this.http.post(`${this.url}/updatePurchaseOrder`, item);
  }

  deletePurchaseOrder(id) {
    return this.http.post(`${this.url}/deletePurchaseOrder`, { id: id });
  }
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { ButtonRendererComponent } from './../renderer/button-renderer.component';
import { NgbModal, ModalDismissReasons, NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { PurchaseOrdersService } from './service/purchase-orders.service';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { GridOptions } from 'ag-grid-community';
import { CurrenciesService } from '../currencies/service/currencies.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-purchase-orders',
  templateUrl: './purchase-orders.component.html',
  styleUrls: ['./purchase-orders.component.scss']
})
export class PurchaseOrdersComponent implements OnInit {

  closeResult = '';
  frameworkComponents: any;
  isEdit: boolean;
  staticAlertClosed = false;
  successMessage = '';
  itemGroupId: number;
  private _success = new Subject<string>();
  itemToBeDeleted;
  paginationPageSize;
  searchText;

  country_list: any = [{ id: 1, title: "India" }, { id: 2, title: "UK" }, { id: 3, title: "USA" }];
  state_list: any = [{ id: 1, title: "Tamil Nadu" }, { id: 2, title: "Delhi" }, { id: 3, title: "Mumbai" }];
  city_list: any = [{ id: 1, title: "Trichy" }, { id: 2, title: "Chennai" }, { id: 3, title: "Madurai" }];
  currency_list;

  @ViewChild('content', { static: false }) private content;
  @ViewChild('confirmModel', { static: false }) private confirmModel;
  @ViewChild('staticAlert', { static: false }) staticAlert: NgbAlert;
  @ViewChild('selfClosingAlert', { static: false }) selfClosingAlert: NgbAlert;


  purchase_orders = { title: 0, supplier: '',contract: '', order_date: '', text_a: '', text_b: '', buyer: 0, header_text: '',  currency: '', terms_of_payment: '', terms_of_delivery: '', position_number: 0, item: '', description: '', warehouse: '', ordered_qty: 0, unit: '', price: 0, lines_discount: 0, tax: 0, amount: 0, planned_delivery_date: '', confirmed_delivery_date:'', id: 0 };
  formModalReference;
  submitted = false;
  form = new FormGroup({
    title: new FormControl('', Validators.required),
    supplier: new FormControl('', Validators.required),
    contract: new FormControl('', Validators.required),
    order_date: new FormControl('', Validators.required),
    text_a: new FormControl('', Validators.required),
    text_b: new FormControl('', Validators.required),
    buyer: new FormControl('', Validators.required),
    header_text: new FormControl('', Validators.required),
    currency: new FormControl('', Validators.required),
    terms_of_payment: new FormControl('', Validators.required),
    terms_of_delivery: new FormControl('', Validators.required),
    position_number: new FormControl('', Validators.required),
    item: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required),
    warehouse: new FormControl('', Validators.required),
    ordered_qty: new FormControl('', Validators.required),
    unit: new FormControl('', Validators.required),
    price: new FormControl('', Validators.required),
    lines_discount: new FormControl('', Validators.required),
    tax: new FormControl('', Validators.required),
    amount: new FormControl('', Validators.required),
    planned_delivery_date: new FormControl('', Validators.required),
    confirmed_delivery_date: new FormControl('', Validators.required)
  });

  hashValueGetter = function (params) {
    return ++params.node.rowIndex;
  };

  columnDefs = [
    {
      headerName: 'Sno', field: '', maxWidth: 100, valueGetter: this.hashValueGetter,
    },
    {
      headerName: 'Purchase Order', field: 'title', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Supplier', field: 'supplier', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Contract', field: 'contract', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Order Date', field: 'order_date', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Currency', field: 'currency', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Text A', field: 'text_a', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Text B', field: 'text_b', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Terms Of Payment', field: 'terms_of_payment', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Terms Of Delivery', field: 'terms_of_delivery', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Buyer', field: 'buyer', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Header Text', field: 'header_text', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },

    {
      headerName: 'Position Number', field: 'position_number', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Item', field: 'item', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Description', field: 'description', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Warehouse', field: 'warehouse', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Planned Delivery Date', field: 'planned_delivery_date', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Confirmed Delivery date', field: 'confirmed_delivery_date', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Ordered Qty', field: 'ordered_qty', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Unit', field: 'unit', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Price', field: 'price', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Lines Discount', field: 'lines_discount', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Tax', field: 'tax', width: 150, resizable: true, sortable: true, filter: true, unSortIcon: true
    },
    {
      headerName: 'Amount', field: 'amount', width: 150, resizable: true, sortable: true, filter: true,
      unSortIcon: true
    },
    {
      headerName: 'Action',
      width: 90,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.onBtnClick.bind(this),
        // label: 'Edit',
        icon: 'fa fa-edit'
      }
    },
    {
      headerName: '',
      width: 110,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.deleteItem.bind(this),
        // label: 'Delete',
        icon: 'fa fa-trash'
      }
    },
  ];

  rowData = [
  ];

  gridOptions: GridOptions = {
    columnDefs: this.columnDefs,
    rowData: null,
    getRowStyle: this.getRowStyleScheduled
  };
  gridApi: any;
  gridColumnApi: any;
  rowClassRules: any;
  inValidRowNode: boolean;

  constructor(private modalService: NgbModal, private currencyService: CurrenciesService, private purchaseOrdersService: PurchaseOrdersService, private datePipe: DatePipe) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.isEdit = false;
    if (this.staticAlert) {
      setTimeout(() => this.staticAlert.close(), 20000);
    }
    this._success.subscribe(message => this.successMessage = message);
    this._success.pipe(debounceTime(5000)).subscribe(() => {
      if (this.selfClosingAlert) {
        this.selfClosingAlert.close();
      }
    });
    this.getCurrencyList();
    this.paginationPageSize = 10;
  }

  getCurrencyList() {
    this.currencyService.getAllCurrency().subscribe((res: any) => {
      this.currency_list = res.recordset;
    });
  }

  getRowStyleScheduled(params) {
    if (params.node.rowIndex % 2 == 0) {
      return {
        'background-color': 'rgba(0,0,0,.05)',
      }
    }
    return null;
  };


  get f() { return this.form.controls; }

  open(content) {
    this.modalService.open(content, {size: 'lg', ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onSubmit() {
    this.submitted = true;
    let close: any = document.querySelector('#closeForm');
    if (this.form.invalid) {
      return;
    }
    else {
      this.purchase_orders.supplier = this.purchase_orders.supplier.trim();
      this.purchase_orders.description = this.purchase_orders.description.trim();
      this.purchase_orders.contract = this.purchase_orders.contract.trim();
      this.purchase_orders.text_a = this.purchase_orders.text_a.trim();
      this.purchase_orders.text_b = this.purchase_orders.text_b.trim();
      this.purchase_orders.currency = this.purchase_orders.currency.trim();
      this.purchase_orders.terms_of_delivery = this.purchase_orders.terms_of_delivery.trim();
      this.purchase_orders.warehouse = this.purchase_orders.warehouse.trim();
      this.purchase_orders.terms_of_payment = this.purchase_orders.terms_of_payment.trim();
      this.purchase_orders.item = this.purchase_orders.item.trim();
      this.purchase_orders.unit = this.purchase_orders.unit.trim();
      this.purchase_orders.header_text = this.purchase_orders.header_text.trim();
      if (!this.isEdit) {
        this.purchaseOrdersService.addPurchaseOrder(this.purchase_orders).subscribe((res) => {
          console.log(res);
          close.click();
          this.itemGroupId = 0;
          this.submitted = false;
          this._success.next(`Data Saved Successfully`);
          this.getAllPurchaseOrders();
        });
      }
      else {
        this.purchaseOrdersService.updatePurchaseOrder(this.purchase_orders).subscribe((res: any) => {
          this.isEdit = false;
          if (res && res.rowsAffected) {
            this.submitted = false;
            close.click();
            this._success.next(`Data Updated Successfully`);
            this.getAllPurchaseOrders();
          }
        });
      }
      this.purchase_orders = { title: 0, supplier: '',contract: '', order_date: '', text_a: '', text_b: '', buyer: 0, header_text: '',  currency: '', terms_of_payment: '', terms_of_delivery: '', position_number: 0, item: '', description: '', warehouse: '', ordered_qty: 0, unit: '', price: 0, lines_discount: 0, tax: 0, amount: 0, planned_delivery_date: '', confirmed_delivery_date:'', id: 0 };

    }
  }


  onBtnClick(row) {
    this.isEdit = true;
    this.itemGroupId = row.rowData.id;
    this.purchaseOrdersService.findPurchaseOrder(this.itemGroupId).subscribe((res: any) => {
      this.purchase_orders.id = this.itemGroupId;
      this.purchase_orders = res.recordset[0];
    })
    this.open(this.content);
  }

  deleteItem(row) {
    this.itemGroupId = row.rowData.id;
    this.itemToBeDeleted = row.rowData.title;
    this.open(this.confirmModel);
  }

  deleteClose() {

    let closeDel: any = document.querySelector('#closeDel');
    this.purchaseOrdersService.deletePurchaseOrder(this.itemGroupId).subscribe((res) => {
      closeDel.click();
      this._success.next(`Deleted Successfully`);
      this.getAllPurchaseOrders();
    })
  }

  getAllPurchaseOrders() {
    this.purchaseOrdersService.getAllPurchaseOrders().subscribe((res: any) => {
      for (let i = 0; i < res.recordset.length; i++) {
        res.recordset[i].order_date = this.datePipe.transform(res.recordset[i].order_date, 'dd-MM-yyyy');
        res.recordset[i].planned_delivery_date = this.datePipe.transform(res.recordset[i].planned_delivery_date, 'dd-MM-yyyy');
        res.recordset[i].confirmed_delivery_date = this.datePipe.transform(res.recordset[i].confirmed_delivery_date, 'dd-MM-yyyy');
      }
      this.rowData = res.recordset;
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.purchaseOrdersService.getAllPurchaseOrders().subscribe((res: any) => {
      for (let i = 0; i < res.recordset.length; i++) {
        res.recordset[i].order_date = this.datePipe.transform(res.recordset[i].order_date, 'dd-MM-yyyy');
        res.recordset[i].planned_delivery_date = this.datePipe.transform(res.recordset[i].planned_delivery_date, 'dd-MM-yyyy');
        res.recordset[i].confirmed_delivery_date = this.datePipe.transform(res.recordset[i].confirmed_delivery_date, 'dd-MM-yyyy');
      }
      params.api.setRowData(res.recordset)
    })
  }

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchText);
  }

}
